#include "Prediction.h"
#include "Storage.h"
#include "Utils.h"
#include "HardwareConfig.h"

const uint8_t K_NEIGHBORS = 15;
const uint8_t MIN_REQUIRED = 3;
const uint8_t MIN_RELIABLE = 8;
const uint16_t MAX_SCAN_RECORDS = 180;

const uint16_t SEARCH_PENALTY_STAGE_1 = 0;
const uint16_t SEARCH_PENALTY_STAGE_2 = 60;
const uint16_t SEARCH_PENALTY_STAGE_3 = 140;
const uint16_t SEARCH_PENALTY_STAGE_4 = 220;
const uint16_t SEARCH_PENALTY_STAGE_5 = 320;

const uint8_t SEARCH_STAGE_INIT = 6;
const uint16_t SEARCH_PENALTY_INIT_FALLBACK = 600;
const uint16_t MAX_INIT_SCAN_RECORDS = 365;

struct HeapNode {
    uint32_t distance;
    uint32_t timestampKey;
    uint8_t menuA;
    uint8_t menuB;
    uint8_t menuC;
    uint8_t searchStage;
};

static HeapNode heap[K_NEIGHBORS];
static uint8_t heapSize = 0;
static uint16_t scannedRecords = 0;

static void clearPredictionResult(PredictResult* out) {
    if (out == NULL) return;
    out->menuA = 0;
    out->menuB = 0;
    out->menuC = 0;
    out->confidenceLevel = CONF_NONE;
    out->usedCount = 0;
    out->maxStageUsed = 0;
    out->lowDataFlag = true;
    out->valid = false;
}

static bool validRecordBasic(const SalesRecord* r) {
    if (r == NULL) return false;
    if (r->month < 1 || r->month > 12) return false;
    if (r->day < 1 || r->day > 31) return false;
    if (r->hour > 23) return false;
    if (r->cdsValue > 1023 || r->irValue > 1023) return false;
    if (!isOpenHour(r->hour)) return false;
    return true;
}

static uint16_t normScoreU32(uint32_t delta, uint16_t divisor, uint16_t cap) {
    uint32_t v = (delta + (divisor / 2)) / divisor;
    if (v > cap) v = cap;
    return (uint16_t)v;
}

static uint8_t circularDayDiff(uint8_t a, uint8_t b) {
    uint8_t d = (a > b) ? (a - b) : (b - a);
    return (d > 3) ? (7 - d) : d;
}

static uint16_t ageMonths(const PredictionContext* ctx, const SalesRecord* r) {
    int16_t targetM = (int16_t)ctx->yearOffset * 12 + (int16_t)ctx->month;
    int16_t recordM = (int16_t)r->yearOffset * 12 + (int16_t)r->month;
    if (recordM > targetM) return 0;
    uint16_t age = (uint16_t)(targetM - recordM);
    return (age > 24) ? 24 : age;
}

static uint32_t calculateDistance(const PredictionContext* ctx, const SalesRecord* r, uint16_t searchPenalty) {
    uint32_t score = 0;

    score += (uint32_t)normScoreU32(absDiff16(ctx->airTemp10, r->airTemp10), 10, 40) * 5U;
    score += (uint32_t)normScoreU32(absDiff16(ctx->humidity2, r->humidity2), 4, 25) * 2U;
    score += (uint32_t)normScoreU32(absDiff16(ctx->floorTemp10, r->floorTemp10), 10, 40) * 2U;
    score += (uint32_t)normScoreU32(absDiff16(ctx->cdsValue, r->cdsValue), 40, 30) * 2U;
    score += (uint32_t)normScoreU32(absDiff16(ctx->irValue, r->irValue), 60, 20);

    uint8_t recDow = getDayOfWeek(r->yearOffset, r->month, r->day);
    score += (uint32_t)circularDayDiff(ctx->dayOfWeek, recDow) * 25U;

    score += (uint32_t)ageMonths(ctx, r) * 8U;
    score += searchPenalty;

    return score;
}

static void insertCandidateIntoHeap(const SalesRecord* r, uint32_t distance, uint8_t searchStage) {
    if (r == NULL) return;

    uint32_t key = makeTimestampKey(r->yearOffset, r->month, r->day, r->hour);

    for (uint8_t i = 0; i < heapSize; i++) {
        if (heap[i].timestampKey == key) {
            heap[i].menuA = satAddU8(heap[i].menuA, r->menuA);
            heap[i].menuB = satAddU8(heap[i].menuB, r->menuB);
            heap[i].menuC = satAddU8(heap[i].menuC, r->menuC);
            if (distance < heap[i].distance) {
                heap[i].distance = distance;
                heap[i].searchStage = searchStage;
            }
            return;
        }
    }

    if (heapSize < K_NEIGHBORS) {
        heap[heapSize].distance = distance;
        heap[heapSize].timestampKey = key;
        heap[heapSize].menuA = r->menuA;
        heap[heapSize].menuB = r->menuB;
        heap[heapSize].menuC = r->menuC;
        heap[heapSize].searchStage = searchStage;
        heapSize++;
        return;
    }

    uint8_t worstIdx = 0;
    for (uint8_t i = 1; i < heapSize; i++) {
        if (heap[i].distance > heap[worstIdx].distance) {
            worstIdx = i;
        }
    }

    if (distance < heap[worstIdx].distance) {
        heap[worstIdx].distance = distance;
        heap[worstIdx].timestampKey = key;
        heap[worstIdx].menuA = r->menuA;
        heap[worstIdx].menuB = r->menuB;
        heap[worstIdx].menuC = r->menuC;
        heap[worstIdx].searchStage = searchStage;
    }
}

static bool scanOneSalesFile(const PredictionContext* ctx, const char* fileName, uint8_t searchStage, uint16_t penalty) {
    if (ctx == NULL || fileName == NULL) return true;
    if (scannedRecords >= MAX_SCAN_RECORDS) return true;

    File file = SD.open(fileName, FILE_READ);
    if (!file) {
        storageMarkAccessError();
        return false;
    }

    bool ok = true;
    SalesRecord r;
    while (scannedRecords < MAX_SCAN_RECORDS) {
        int n = file.read((uint8_t*)&r, sizeof(SalesRecord));
        if (n == sizeof(SalesRecord)) {
            scannedRecords++;

            if (!validRecordBasic(&r)) continue;
            if (r.hour != ctx->hour && searchStage != 5) continue;
            if (isFutureRecord(ctx, &r)) continue;

            uint32_t distance = calculateDistance(ctx, &r, penalty);
            insertCandidateIntoHeap(&r, distance, searchStage);
            continue;
        }

        if (n == 0) {
            break;
        }

        storageMarkAccessError();
        ok = false;
        break;
    }

    file.close();
    return ok;
}

static void scanCandidateFileIfExists(const PredictionContext* ctx,
                                      uint8_t isHoliday,
                                      uint8_t hour,
                                      uint8_t tempZone,
                                      uint8_t lightZone,
                                      uint8_t searchStage,
                                      uint16_t penalty) {
    if (hour > 23 || tempZone < 1 || tempZone > 4 || lightZone < 1 || lightZone > 3) return;
    char fileName[13];
    buildSalesFileName(fileName, sizeof(fileName), isHoliday, hour, tempZone, lightZone);

    /*
       Do not call SD.exists() here.  Prediction should rely on the boot-time
       fileCache and on cache-bit updates after writes/deletes.  Calling
       SD.exists() for cache misses reintroduces SD card probing during normal
       prediction and can make a removed card look like ordinary DATA LOW.
       If a cached file fails to open, scanOneSalesFile() marks an access error
       and the main sketch performs a quick root check before entering
       SD_MISSING.
    */
    bool expectedByCache = isFileCacheBitSet(isHoliday, hour, tempZone, lightZone);
    if (!expectedByCache) {
        return;
    }

    if (!scanOneSalesFile(ctx, fileName, searchStage, penalty)) {
        clearFileCacheBit(isHoliday, hour, tempZone, lightZone);
    }
}

static bool isNeighborCondition(uint8_t baseTempZone, uint8_t baseLightZone, uint8_t tempZone, uint8_t lightZone) {
    int8_t dt = (int8_t)tempZone - (int8_t)baseTempZone;
    int8_t dl = (int8_t)lightZone - (int8_t)baseLightZone;
    if (dt < 0) dt = (int8_t)-dt;
    if (dl < 0) dl = (int8_t)-dl;
    return (dt <= 1 && dl <= 1);
}

static void scanRealCandidateFiles(const PredictionContext* ctx, uint8_t tempZone, uint8_t lightZone) {
    if (ctx == NULL) return;

    scanCandidateFileIfExists(ctx, ctx->isHoliday, ctx->hour, tempZone, lightZone, 1, SEARCH_PENALTY_STAGE_1);

    for (int8_t dt = -1; dt <= 1; dt++) {
        for (int8_t dl = -1; dl <= 1; dl++) {
            uint8_t tz = (uint8_t)((int8_t)tempZone + dt);
            uint8_t lz = (uint8_t)((int8_t)lightZone + dl);
            if (tz == tempZone && lz == lightZone) continue;
            if (tz < 1 || tz > 4 || lz < 1 || lz > 3) continue;
            scanCandidateFileIfExists(ctx, ctx->isHoliday, ctx->hour, tz, lz, 2, SEARCH_PENALTY_STAGE_2);
        }
    }

    for (uint8_t tz = 1; tz <= 4; tz++) {
        for (uint8_t lz = 1; lz <= 3; lz++) {
            if (tz == tempZone && lz == lightZone) continue;
            /*
               Stage 2 already scanned the adjacent temp/light cells.
               Do not scan those same files again at Stage 3; duplicated reads
               waste SD time and can consume MAX_SCAN_RECORDS before reaching
               truly wider-condition files.
            */
            if (isNeighborCondition(tempZone, lightZone, tz, lz)) continue;
            scanCandidateFileIfExists(ctx, ctx->isHoliday, ctx->hour, tz, lz, 3, SEARCH_PENALTY_STAGE_3);
        }
    }

    scanCandidateFileIfExists(ctx, ctx->isHoliday ? 0 : 1, ctx->hour, tempZone, lightZone, 4, SEARCH_PENALTY_STAGE_4);

    if (ctx->hour > 0) {
        scanCandidateFileIfExists(ctx, ctx->isHoliday, ctx->hour - 1, tempZone, lightZone, 5, SEARCH_PENALTY_STAGE_5);
    }
    if (ctx->hour < 23) {
        scanCandidateFileIfExists(ctx, ctx->isHoliday, ctx->hour + 1, tempZone, lightZone, 5, SEARCH_PENALTY_STAGE_5);
    }
}

static uint8_t countRealCandidatesInHeap(void) {
    uint8_t n = 0;
    for (uint8_t i = 0; i < heapSize; i++) {
        if (heap[i].searchStage != SEARCH_STAGE_INIT) n++;
    }
    return n;
}

static uint8_t countInitCandidatesInHeap(void) {
    uint8_t n = 0;
    for (uint8_t i = 0; i < heapSize; i++) {
        if (heap[i].searchStage == SEARCH_STAGE_INIT) n++;
    }
    return n;
}

static bool isValidInitRecord(const PredictionContext* ctx, const SalesRecord* r) {
    if (ctx == NULL || r == NULL) return false;
    if (!validRecordBasic(r)) return false;
    if (r->hour != ctx->hour) return false;
    return true;
}

static uint16_t scanInitFallbackCandidates(const PredictionContext* ctx) {
    if (ctx == NULL) return 0;
    if (!isInitFallbackAvailable()) return 0;

    uint16_t added = 0;
    for (uint16_t dayIndex = 0; dayIndex < 365; dayIndex++) {
        if (added >= MAX_INIT_SCAN_RECORDS) break;

        uint16_t recordIndex = (uint16_t)(dayIndex * 24U + ctx->hour);
        SalesRecord r;
        if (!readInitRecordAt(recordIndex, &r)) continue;
        if (!isValidInitRecord(ctx, &r)) continue;

        uint32_t d = calculateDistance(ctx, &r, SEARCH_PENALTY_INIT_FALLBACK);
        insertCandidateIntoHeap(&r, d, SEARCH_STAGE_INIT);
        added++;
    }

    return added;
}

static uint8_t maxSearchStageInHeap(void) {
    uint8_t m = 0;
    for (uint8_t i = 0; i < heapSize; i++) {
        if (heap[i].searchStage > m) m = heap[i].searchStage;
    }
    return m;
}

static uint8_t normalizeConfidenceForCandidateCount(uint8_t candidateCount, uint8_t calculatedConfidence) {
    /*
       DATA LOW should mean no usable records at all.
       If at least one candidate exists, keep a displayable prediction and
       cap/raise its confidence to LOW when the dataset is too small.
    */
    if (candidateCount == 0) return CONF_NONE;
    if (candidateCount < MIN_REQUIRED) return CONF_LOW;
    if (calculatedConfidence == CONF_NONE) return CONF_LOW;
    if (calculatedConfidence > CONF_HIGH) return CONF_LOW;
    return calculatedConfidence;
}

static void calculateWeightedAverageFromHeap(PredictResult* out) {
    uint32_t sumWA = 0;
    uint32_t sumWB = 0;
    uint32_t sumWC = 0;
    uint32_t sumW = 0;
    uint32_t sumDist = 0;

    if (out == NULL) return;

    if (heapSize == 0) {
        out->menuA = 0;
        out->menuB = 0;
        out->menuC = 0;
        out->confidenceLevel = CONF_NONE;
        return;
    }

    for (uint8_t i = 0; i < heapSize; i++) {
        uint32_t w = 1000UL / (heap[i].distance + 1UL);
        if (w == 0) w = 1;
        sumWA += (uint32_t)heap[i].menuA * w;
        sumWB += (uint32_t)heap[i].menuB * w;
        sumWC += (uint32_t)heap[i].menuC * w;
        sumW += w;
        sumDist += heap[i].distance;
    }

    if (sumW == 0) {
        out->menuA = 0;
        out->menuB = 0;
        out->menuC = 0;
        out->confidenceLevel = normalizeConfidenceForCandidateCount(heapSize, CONF_NONE);
        return;
    }

    out->menuA = clampU8FromU16((uint16_t)((sumWA + sumW / 2UL) / sumW));
    out->menuB = clampU8FromU16((uint16_t)((sumWB + sumW / 2UL) / sumW));
    out->menuC = clampU8FromU16((uint16_t)((sumWC + sumW / 2UL) / sumW));

    uint32_t avgDist = sumDist / heapSize;
    if (heapSize >= MIN_RELIABLE && avgDist < 240UL) out->confidenceLevel = CONF_HIGH;
    else if (heapSize >= MIN_REQUIRED && avgDist < 500UL) out->confidenceLevel = CONF_MED;
    else out->confidenceLevel = CONF_LOW;

    out->confidenceLevel = normalizeConfidenceForCandidateCount(heapSize, out->confidenceLevel);
}

bool executePredictOneHour(const PredictionContext* ctx, PredictResult* out) {
    if (ctx == NULL || out == NULL) return false;
    clearPredictionResult(out);

    if (ctx->hour > 23) return false;
    if (!isOpenHour(ctx->hour)) {
        out->confidenceLevel = CONF_NONE;
        out->valid = false;
        return false;
    }

    heapSize = 0;
    scannedRecords = 0;

    uint8_t tempZone = getTempZone(ctx->airTemp10);
    uint8_t lightZone = getLightZone(ctx->cdsValue);

    scanRealCandidateFiles(ctx, tempZone, lightZone);

    /*
       Prediction display no longer requires MIN_REQUIRED candidates.
       For the demo/prediction UI, a small-but-nonzero dataset should still
       produce a result with low confidence so the LCD can show how many
       records were used.  Only zero candidates remains a true DATA LOW case.
    */
    if (heapSize == 0) {
        out->usedCount = 0;
        out->confidenceLevel = CONF_NONE;
        out->lowDataFlag = true;
        out->valid = false;
        return false;
    }

    calculateWeightedAverageFromHeap(out);
    out->confidenceLevel = normalizeConfidenceForCandidateCount(heapSize, out->confidenceLevel);
    out->usedCount = heapSize;
    out->maxStageUsed = maxSearchStageInHeap();
    out->lowDataFlag = (out->confidenceLevel <= CONF_LOW);
    out->valid = true;

    return true;
}

bool executePredictRange(const PredictionContext* baseCtx, uint8_t startHour, uint8_t endHour,
                         uint16_t* outA, uint16_t* outB, uint16_t* outC,
                         uint8_t* outConfidence, uint8_t* outUsed, uint8_t* outMaxStage) {
    if (baseCtx == NULL || outA == NULL || outB == NULL || outC == NULL ||
        outConfidence == NULL || outUsed == NULL || outMaxStage == NULL) return false;

    *outA = 0;
    *outB = 0;
    *outC = 0;
    *outConfidence = CONF_HIGH;
    *outUsed = 0;
    *outMaxStage = 0;

    if (startHour >= endHour || endHour > 24) return false;

    bool anyValid = false;
    bool anyOpenHour = false;
    uint8_t openHourCount = 0;
    uint8_t validHourCount = 0;
    uint8_t missingHourCount = 0;

    for (uint8_t h = startHour; h < endHour; h++) {
        /*
           Closed hours are deterministic zero-sales hours, not DATA LOW.
           They should not reduce confidence for the open hours that are
           actually predicted in the same range.
        */
        if (!isOpenHour(h)) {
            continue;
        }

        anyOpenHour = true;
        openHourCount++;

        PredictionContext ctx = *baseCtx;
        ctx.hour = h;

        PredictResult r;
        bool ok = executePredictOneHour(&ctx, &r);
        if (!ok || !r.valid) {
            missingHourCount++;
            if (*outConfidence > CONF_LOW) *outConfidence = CONF_LOW;
            continue;
        }

        anyValid = true;
        validHourCount++;
        *outA += r.menuA;
        *outB += r.menuB;
        *outC += r.menuC;
        {
            uint16_t usedSum = (uint16_t)(*outUsed) + (uint16_t)r.usedCount;
            *outUsed = (usedSum > 255U) ? 255U : (uint8_t)usedSum;
        }
        if (r.maxStageUsed > *outMaxStage) *outMaxStage = r.maxStageUsed;
        if (r.confidenceLevel < *outConfidence) *outConfidence = r.confidenceLevel;
    }

    if (!anyOpenHour) {
        /*
           A completely closed-hour range has a deterministic prediction: 0.
           Return success so the UI does not mislabel it as DATA LOW.
        */
        *outConfidence = CONF_NONE;
        *outUsed = 0;
        return true;
    }

    if (!anyValid) {
        *outConfidence = CONF_NONE;
        *outUsed = 0;
        return false;
    }

    /*
       Range prediction may have data for only part of the requested open-hour
       interval.  Keep the available prediction visible, but force LOW
       confidence so the user does not mistake a partial-range result for a
       full-data result.  Closed hours are ignored because their sales are
       intentionally zero.
    */
    if (missingHourCount > 0 || validHourCount < openHourCount) {
        *outConfidence = CONF_LOW;
    }
    *outConfidence = normalizeConfidenceForCandidateCount(*outUsed, *outConfidence);

    return true;
}
