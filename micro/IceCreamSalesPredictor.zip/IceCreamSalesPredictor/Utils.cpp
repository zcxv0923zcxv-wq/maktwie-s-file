#include "Utils.h"
#include <avr/pgmspace.h>

const uint8_t OPEN_START_HOUR = 10;
const uint8_t OPEN_END_HOUR = 22;

bool isLeapYearOffset(uint8_t yearOffset) {
    uint16_t y = 2000U + yearOffset;
    if ((y % 400U) == 0U) return true;
    if ((y % 100U) == 0U) return false;
    return (y % 4U) == 0U;
}

static const uint8_t MONTH_DAYS[12] PROGMEM = {31,28,31,30,31,30,31,31,30,31,30,31};

uint8_t daysInMonth(uint8_t yearOffset, uint8_t month) {
    if (month < 1 || month > 12) return 31;
    if (month == 2 && isLeapYearOffset(yearOffset)) return 29;
    return pgm_read_byte(&MONTH_DAYS[month - 1]);
}

uint16_t dayOfYear(uint8_t yearOffset, uint8_t month, uint8_t day) {
    uint16_t d = 0;
    for (uint8_t m = 1; m < month; m++) {
        d += daysInMonth(yearOffset, m);
    }
    if (day > 0) d += (uint16_t)(day - 1);
    return d;
}

bool addDaysToDate(uint8_t yearOffset, uint8_t month, uint8_t day, uint16_t addDays,
                   uint8_t* outYearOffset, uint8_t* outMonth, uint8_t* outDay) {
    if (outYearOffset == NULL || outMonth == NULL || outDay == NULL) return false;
    if (month < 1 || month > 12 || day < 1 || day > daysInMonth(yearOffset, month)) return false;

    uint8_t y = yearOffset;
    uint8_t m = month;
    uint8_t d = day;

    while (addDays > 0) {
        d++;
        if (d > daysInMonth(y, m)) {
            d = 1;
            m++;
            if (m > 12) {
                m = 1;
                y++;
            }
        }
        addDays--;
    }

    *outYearOffset = y;
    *outMonth = m;
    *outDay = d;
    return true;
}

uint8_t getDayOfWeek(uint8_t yearOffset, uint8_t month, uint8_t day) {
    uint16_t y = 2000U + yearOffset;
    uint8_t m = month;
    if (m < 3) {
        m += 12;
        y--;
    }
    uint16_t K = y % 100U;
    uint16_t J = y / 100U;
    uint16_t h = (day + (13U * (m + 1U)) / 5U + K + K / 4U + J / 4U + 5U * J) % 7U;
    uint8_t dowSun0 = (uint8_t)((h + 6U) % 7U);
    return (dowSun0 == 0) ? 6 : (dowSun0 - 1);
}

uint8_t getTempZone(int16_t airTemp10) {
    if (airTemp10 < 150) return 1;
    if (airTemp10 < 220) return 2;
    if (airTemp10 < 280) return 3;
    return 4;
}

uint8_t getLightZone(uint16_t cdsValue) {
    if (cdsValue <= 350U) return 1;
    if (cdsValue <= 700U) return 2;
    return 3;
}

bool isOpenHour(uint8_t hour) {
    return (hour >= OPEN_START_HOUR && hour < OPEN_END_HOUR);
}

bool isHolidayDate(uint8_t yearOffset, uint8_t month, uint8_t day) {
    uint8_t dow = getDayOfWeek(yearOffset, month, day);
    if (dow >= 5) return true;
    return false;
}

uint32_t makeTimestampKey(uint8_t y, uint8_t m, uint8_t d, uint8_t h) {
    return ((uint32_t)y << 24) | ((uint32_t)m << 16) | ((uint32_t)d << 8) | (uint32_t)h;
}

bool isFutureRecord(const PredictionContext* ctx, const SalesRecord* r) {
    if (ctx == NULL || r == NULL) return true;
    uint32_t targetKey = makeTimestampKey(ctx->yearOffset, ctx->month, ctx->day, ctx->hour);
    uint32_t recordKey = makeTimestampKey(r->yearOffset, r->month, r->day, r->hour);
    return recordKey > targetKey;
}

uint8_t xorChecksumBytes(const uint8_t* data, uint8_t len) {
    uint8_t v = 0;
    for (uint8_t i = 0; i < len; i++) {
        v ^= data[i];
    }
    return v;
}
