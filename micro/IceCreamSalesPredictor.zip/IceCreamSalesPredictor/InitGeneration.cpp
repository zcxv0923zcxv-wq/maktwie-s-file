#include "InitGeneration.h"
#include "Storage.h"
#include "Utils.h"
#include "HardwareConfig.h"

static uint16_t baseA[24];
static uint16_t baseB[24];
static uint16_t baseC[24];
static uint8_t baseCount[24];
static bool baseReady = false;

static uint8_t getInitStartHour(const InitStatusRecord* st) {
    if (st == NULL) return 0;
    if (st->reserved[0] <= 23U) return st->reserved[0];
    return 0;
}

static bool addHoursToDateTime(uint8_t yearOffset,
                               uint8_t month,
                               uint8_t day,
                               uint8_t hour,
                               uint16_t addHours,
                               uint8_t* outYearOffset,
                               uint8_t* outMonth,
                               uint8_t* outDay,
                               uint8_t* outHour) {
    if (outYearOffset == NULL || outMonth == NULL || outDay == NULL || outHour == NULL) return false;
    if (hour > 23) return false;

    uint16_t addDays = (uint16_t)(addHours / 24U);
    uint8_t targetHour = (uint8_t)(hour + (uint8_t)(addHours % 24U));

    if (targetHour >= 24U) {
        targetHour = (uint8_t)(targetHour - 24U);
        addDays++;
    }

    if (!addDaysToDate(yearOffset, month, day, addDays, outYearOffset, outMonth, outDay)) {
        return false;
    }

    *outHour = targetHour;
    return true;
}

static void clearBaseSales(void) {
    for (uint8_t h = 0; h < 24; h++) {
        baseA[h] = 0;
        baseB[h] = 0;
        baseC[h] = 0;
        baseCount[h] = 0;
    }
    baseReady = false;
}

void initGenerationResetRuntime(void) {
    clearBaseSales();
}



static bool validResetSalesRecord(const SalesRecord* r) {
    if (r == NULL) return false;
    if (r->month < 1 || r->month > 12) return false;
    if (r->day < 1 || r->day > daysInMonth(r->yearOffset, r->month)) return false;
    if (r->hour > 23) return false;
    if (r->cdsValue > 1023 || r->irValue > 1023) return false;
    return true;
}

static uint32_t absoluteHourOf(uint8_t yearOffset, uint8_t month, uint8_t day, uint8_t hour) {
    uint32_t days = 0;
    for (uint8_t y = 0; y < yearOffset; y++) {
        days += isLeapYearOffset(y) ? 366UL : 365UL;
    }
    days += dayOfYear(yearOffset, month, day);
    return days * 24UL + (uint32_t)hour;
}

static uint32_t absoluteHourOfRecord(const SalesRecord* r) {
    if (r == NULL) return 0;
    return absoluteHourOf(r->yearOffset, r->month, r->day, r->hour);
}

static bool readFirstResetCollectRecord(SalesRecord* out) {
    if (out == NULL) return false;
    if (countResetCollectRecords() == 0) return false;
    if (!readResetCollectRecordAt(0, out)) return false;
    return validResetSalesRecord(out);
}

static bool firstResetCollectRecordsAreValid(uint16_t needed) {
    if (countResetCollectRecords() < needed) return false;

    SalesRecord rec;
    uint32_t prevAbsHour = 0;

    for (uint16_t i = 0; i < needed; i++) {
        if (!readResetCollectRecordAt(i, &rec)) return false;
        if (!validResetSalesRecord(&rec)) return false;

        uint32_t absHour = absoluteHourOfRecord(&rec);
        if (i > 0 && absHour != (prevAbsHour + 1UL)) {
            return false;
        }
        prevAbsHour = absHour;
    }
    return true;
}

bool tryImportExternalInitData(InitStatusRecord* st) {
    if (st == NULL) return false;
    if (st->phase == 2 || st->phase == 3) return false;
    if (!firstResetCollectRecordsAreValid(INIT_COLLECT_HOURS_TOTAL)) return false;

    SalesRecord first;
    if (!readFirstResetCollectRecord(&first)) return false;

    st->phase = 2;
    st->startYearOffset = first.yearOffset;
    st->startMonth = first.month;
    st->startDay = first.day;
    st->collectHoursDone = INIT_COLLECT_HOURS_TOTAL;
    st->generateIndex = 0;
    st->totalGenerateCount = INIT_GENERATE_RECORDS_TOTAL;
    st->isComplete = 0;
    st->version = 1;
    st->reserved[0] = first.hour;
    st->reserved[1] = 0;
    st->reserved[2] = INIT_COLLECT_HOURS_TOTAL;

    clearBaseSales();
    return saveInitStatus(st);
}

static bool dateInFirstThreeDays(const InitStatusRecord* st, const SalesRecord* r) {
    if (st == NULL || r == NULL) return false;

    uint8_t startHour = getInitStartHour(st);
    uint8_t ey, em, ed, eh;
    if (!addHoursToDateTime(st->startYearOffset,
                            st->startMonth,
                            st->startDay,
                            startHour,
                            INIT_COLLECT_HOURS_TOTAL,
                            &ey,
                            &em,
                            &ed,
                            &eh)) {
        return false;
    }

    uint32_t startKey = makeTimestampKey(st->startYearOffset, st->startMonth, st->startDay, startHour);
    uint32_t endKey = makeTimestampKey(ey, em, ed, eh);
    uint32_t recKey = makeTimestampKey(r->yearOffset, r->month, r->day, r->hour);

    return recKey >= startKey && recKey < endKey;
}

static bool buildBaseSalesFromThreeDays(const InitStatusRecord* st) {
    (void)st;
    clearBaseSales();

    if (!firstResetCollectRecordsAreValid(INIT_COLLECT_HOURS_TOTAL)) {
        return false;
    }

    SalesRecord rec;
    for (uint16_t i = 0; i < INIT_COLLECT_HOURS_TOTAL; i++) {
        if (!readResetCollectRecordAt(i, &rec)) return false;
        if (!validResetSalesRecord(&rec)) return false;
        if (rec.hour > 23) continue;

        baseA[rec.hour] += rec.menuA;
        baseB[rec.hour] += rec.menuB;
        baseC[rec.hour] += rec.menuC;
        if (baseCount[rec.hour] < 255) {
            baseCount[rec.hour]++;
        }
    }

    for (uint8_t h = 0; h < 24; h++) {
        if (baseCount[h] > 0) {
            baseA[h] = baseA[h] / baseCount[h];
            baseB[h] = baseB[h] / baseCount[h];
            baseC[h] = baseC[h] / baseCount[h];
        } else {
            baseA[h] = 0;
            baseB[h] = 0;
            baseC[h] = 0;
        }
    }

    baseReady = true;
    return true;
}

void beginInitCollectFromReset(InitStatusRecord* st, const DateTimeParts* now) {
    if (st == NULL || now == NULL) return;

    st->phase = 1;
    st->startYearOffset = now->yearOffset;
    st->startMonth = now->month;
    st->startDay = now->day;
    st->collectHoursDone = 0;
    st->generateIndex = 0;
    st->totalGenerateCount = INIT_GENERATE_RECORDS_TOTAL;
    st->isComplete = 0;
    st->version = 1;
    st->checksum = 0;
    st->reserved[0] = now->hour;
    st->reserved[1] = 0;
    st->reserved[2] = 0;

    clearBaseSales();
    saveInitStatus(st);
}

bool updateInitCollectProgressOnHourSaved(InitStatusRecord* st) {
    if (st == NULL) return false;
    if (st->phase != 1) return false;
    if (st->collectHoursDone < INIT_COLLECT_HOURS_TOTAL) {
        st->collectHoursDone++;
    }
    if (st->collectHoursDone >= INIT_COLLECT_HOURS_TOTAL) {
        st->phase = 2;
        st->generateIndex = 0;
        st->isComplete = 0;
    }
    return saveInitStatus(st);
}

bool prepareInitGeneration(InitStatusRecord* st) {
    if (st == NULL) return false;

    WeightHeader wh;
    if (!readWeightHeader(&wh)) return false;

    if (!baseReady) {
        if (!buildBaseSalesFromThreeDays(st)) return false;
    }

    if (st->phase != 2) {
        st->phase = 2;
    }

    if (st->generateIndex > INIT_GENERATE_RECORDS_TOTAL) {
        st->generateIndex = INIT_GENERATE_RECORDS_TOTAL;
    }
    st->totalGenerateCount = INIT_GENERATE_RECORDS_TOTAL;
    st->isComplete = 0;
    st->version = 1;
    return saveInitStatus(st);
}

static bool makeInitSalesRecord(const InitStatusRecord* st,
                                uint16_t generateIndex,
                                SalesRecord* out,
                                uint8_t* outHoliday,
                                uint8_t* outTempZone,
                                uint8_t* outLightZone) {
    if (st == NULL || out == NULL) return false;
    if (generateIndex >= INIT_GENERATE_RECORDS_TOTAL) return false;

    uint8_t startHour = getInitStartHour(st);
    uint16_t addHours = (uint16_t)(INIT_COLLECT_HOURS_TOTAL + generateIndex);

    uint8_t ty, tm, td, targetHour;
    if (!addHoursToDateTime(st->startYearOffset,
                            st->startMonth,
                            st->startDay,
                            startHour,
                            addHours,
                            &ty,
                            &tm,
                            &td,
                            &targetHour)) {
        return false;
    }

    WeightRecord wr;
    if (!readWeightRecordByTargetDate(ty, tm, td, targetHour, &wr)) {
        return false;
    }

    /*
       Store generated records into condition files using the generated target date
       and generated environment values. The weight record may come from a 365-day
       seasonal table, so its holiday flag/date can differ from the actual target
       calendar year, especially around leap-year mapping.
    */
    if (outHoliday != NULL) *outHoliday = isHolidayDate(ty, tm, td) ? 1 : 0;
    if (outTempZone != NULL) *outTempZone = getTempZone(wr.airTemp10);
    if (outLightZone != NULL) *outLightZone = getLightZone(wr.cdsValue);

    int16_t salesIndex = 100 + wr.totalOffset;
    if (salesIndex < 20) salesIndex = 20;
    if (salesIndex > 220) salesIndex = 220;

    uint16_t predA = 0;
    uint16_t predB = 0;
    uint16_t predC = 0;

    if ((wr.flags & WFLAG_OPEN_HOUR) && isOpenHour(targetHour)) {
        predA = (uint16_t)(((uint32_t)baseA[targetHour] * (uint16_t)salesIndex + 50UL) / 100UL);
        predB = (uint16_t)(((uint32_t)baseB[targetHour] * (uint16_t)salesIndex + 50UL) / 100UL);
        predC = (uint16_t)(((uint32_t)baseC[targetHour] * (uint16_t)salesIndex + 50UL) / 100UL);
    }

    out->yearOffset = ty;
    out->month = tm;
    out->day = td;
    out->hour = targetHour;
    out->airTemp10 = wr.airTemp10;
    out->humidity2 = wr.humidity2;
    out->floorTemp10 = wr.floorTemp10;
    out->cdsValue = wr.cdsValue;
    out->irValue = wr.irValue;
    out->menuA = clampU8FromU16(predA);
    out->menuB = clampU8FromU16(predB);
    out->menuC = clampU8FromU16(predC);

    if (!isOpenHour(targetHour)) {
        out->menuA = 0;
        out->menuB = 0;
        out->menuC = 0;
    }

    return true;
}

bool generateNextInitRecord(InitStatusRecord* st) {
    if (st == NULL) return false;

    if (st->phase != 2) {
        st->phase = 2;
    }

    if (!baseReady) {
        if (!prepareInitGeneration(st)) return false;
    }

    if (st->generateIndex >= INIT_GENERATE_RECORDS_TOTAL) {
        st->phase = 3;
        st->isComplete = 1;
        st->generateIndex = INIT_GENERATE_RECORDS_TOTAL;
        return saveInitStatus(st);
    }

    SalesRecord rec;
    uint8_t recHoliday = 0;
    uint8_t recTempZone = 1;
    uint8_t recLightZone = 1;

    if (!makeInitSalesRecord(st, st->generateIndex, &rec, &recHoliday, &recTempZone, &recLightZone)) {
        return false;
    }

    if (!saveGeneratedInitRecordToSalesFile(&rec, recHoliday, recTempZone, recLightZone)) {
        return false;
    }

    st->generateIndex++;
    if (st->generateIndex >= INIT_GENERATE_RECORDS_TOTAL) {
        st->phase = 3;
        st->isComplete = 1;
    }

    return saveInitStatus(st);
}

bool isInitGenerationComplete(const InitStatusRecord* st) {
    if (st == NULL) return false;
    return st->phase == 3 && st->isComplete == 1 && st->generateIndex >= INIT_GENERATE_RECORDS_TOTAL;
}

uint8_t currentInitCollectDay(const InitStatusRecord* st) {
    if (st == NULL) return 1;
    uint8_t dayNum = (uint8_t)(st->collectHoursDone / 24U) + 1;
    if (dayNum < 1) dayNum = 1;
    if (dayNum > 3) dayNum = 3;
    return dayNum;
}
