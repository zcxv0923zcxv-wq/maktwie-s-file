#include "Storage.h"
#include "HardwareConfig.h"
#include "Utils.h"

#include <SPI.h>
#include <string.h>
#include <avr/pgmspace.h>

static uint8_t fileCache[72];
static bool storageAccessError = false;

static bool ensureResetFolder(void);
bool clearResetCollectData(void);


void storageClearAccessError(void) {
    storageAccessError = false;
}

void storageMarkAccessError(void) {
    storageAccessError = true;
}

bool storageHadAccessError(void) {
    return storageAccessError;
}

bool storageQuickCheck(void) {
    File root = SD.open("/");
    if (root) {
        root.close();
        return true;
    }
    return false;
}

bool storageRefresh(void) {
    /*
       SD modules can be slow to become ready after reset or hot insertion.
       Make each explicit refresh robust, but keep it bounded so the UI does not
       appear frozen.  This function is called only at SD-dependent points, not
       continuously in the normal loop.
    */
    clearFileCache();

    pinMode(SS, OUTPUT);
    digitalWrite(SS, HIGH);
    pinMode(SD_CS_PIN, OUTPUT);
    digitalWrite(SD_CS_PIN, HIGH);
    SPI.begin();

    for (uint8_t attempt = 0; attempt < 3; attempt++) {
        delay(80);
        if (SD.begin(SD_CS_PIN)) {
            File root = SD.open("/");
            if (root) {
                root.close();
                rebuildFileCache();
                storageClearAccessError();
                return true;
            }
        }
        delay(120);
    }

    clearFileCache();
    storageMarkAccessError();
    return false;
}

bool storageBegin(void) {
    return storageRefresh();
}

void clearFileCache(void) {
    for (uint8_t i = 0; i < sizeof(fileCache); i++) {
        fileCache[i] = 0;
    }
}

static uint16_t getFileCacheBitIndex(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone) {
    if (hour > 23) hour = 23;
    if (tempZone < 1) tempZone = 1;
    if (tempZone > 4) tempZone = 4;
    if (lightZone < 1) lightZone = 1;
    if (lightZone > 3) lightZone = 3;
    return (uint16_t)(isHoliday ? 288 : 0) + (uint16_t)hour * 12U + (uint16_t)(tempZone - 1) * 3U + (uint16_t)(lightZone - 1);
}

bool isFileCacheBitSet(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone) {
    uint16_t bitIdx = getFileCacheBitIndex(isHoliday, hour, tempZone, lightZone);
    return (fileCache[bitIdx / 8] & (1 << (bitIdx % 8))) != 0;
}

void setFileCacheBit(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone) {
    uint16_t bitIdx = getFileCacheBitIndex(isHoliday, hour, tempZone, lightZone);
    fileCache[bitIdx / 8] |= (1 << (bitIdx % 8));
}

void clearFileCacheBit(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone) {
    uint16_t bitIdx = getFileCacheBitIndex(isHoliday, hour, tempZone, lightZone);
    fileCache[bitIdx / 8] &= ~(1 << (bitIdx % 8));
}

void buildSalesFileName(char* fileName, size_t fileNameSize, uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone) {
    if (fileName == NULL || fileNameSize < 13) {
        if (fileName != NULL && fileNameSize > 0) fileName[0] = '\0';
        return;
    }
    if (hour > 23) hour = 23;
    if (tempZone < 1) tempZone = 1;
    if (tempZone > 4) tempZone = 4;
    if (lightZone < 1) lightZone = 1;
    if (lightZone > 3) lightZone = 3;
    snprintf_P(fileName, fileNameSize, PSTR("%c%02uT%uL%u.BIN"),
               isHoliday ? 'H' : 'W',
               (unsigned)hour,
               (unsigned)tempZone,
               (unsigned)lightZone);
}

void rebuildFileCache(void) {
    clearFileCache();
    char fileName[13];

    for (uint8_t hFlag = 0; hFlag < 2; hFlag++) {
        for (uint8_t hour = 0; hour < 24; hour++) {
            for (uint8_t tz = 1; tz <= 4; tz++) {
                for (uint8_t lz = 1; lz <= 3; lz++) {
                    buildSalesFileName(fileName, sizeof(fileName), hFlag, hour, tz, lz);
                    if (SD.exists(fileName)) {
                        setFileCacheBit(hFlag, hour, tz, lz);
                    }
                }
            }
        }
    }
}

bool overwriteRecordAt(File* file, uint32_t pos, const SalesRecord* record) {
    if (file == NULL || record == NULL) return false;
    if (!file->seek(pos)) {
        storageMarkAccessError();
        return false;
    }

    size_t written = file->write((const uint8_t*)record, sizeof(SalesRecord));
    file->flush();
    if (written != sizeof(SalesRecord)) {
        storageMarkAccessError();
        return false;
    }

    /*
       Some SD library variants open FILE_WRITE with append semantics.
       In that case seek(pos) may not really overwrite the old bytes even if
       write() returns 16. Verify the bytes at pos before reporting success.
    */
    SalesRecord verify;
    if (!file->seek(pos)) {
        storageMarkAccessError();
        return false;
    }
    if (file->read((uint8_t*)&verify, sizeof(SalesRecord)) != sizeof(SalesRecord)) {
        storageMarkAccessError();
        return false;
    }

    return memcmp(&verify, record, sizeof(SalesRecord)) == 0;
}

static bool sameTimestamp(const SalesRecord* a, const SalesRecord* b) {
    return a != NULL && b != NULL &&
           a->yearOffset == b->yearOffset &&
           a->month == b->month &&
           a->day == b->day &&
           a->hour == b->hour;
}

#define TEMP_REWRITE_FILE "TMPREC.BIN"

static bool rewriteFileWithoutTimestamp(const char* fileName,
                                        const SalesRecord* target,
                                        bool* removedAny,
                                        bool* remainedAny) {
    if (removedAny != NULL) *removedAny = false;
    if (remainedAny != NULL) *remainedAny = false;

    if (fileName == NULL || target == NULL) return false;
    if (!SD.exists(fileName)) return true;

    if (SD.exists(TEMP_REWRITE_FILE)) {
        if (!SD.remove(TEMP_REWRITE_FILE)) {
            storageMarkAccessError();
            return false;
        }
    }

    File src = SD.open(fileName, FILE_READ);
    if (!src) {
        storageMarkAccessError();
        return false;
    }

    File tmp = SD.open(TEMP_REWRITE_FILE, FILE_WRITE);
    if (!tmp) {
        src.close();
        storageMarkAccessError();
        return false;
    }

    bool ok = true;
    bool removed = false;
    bool remained = false;
    SalesRecord rec;

    while (true) {
        int n = src.read((uint8_t*)&rec, sizeof(SalesRecord));
        if (n == sizeof(SalesRecord)) {
            if (sameTimestamp(&rec, target)) {
                removed = true;
                continue;
            }

            if (tmp.write((const uint8_t*)&rec, sizeof(SalesRecord)) != sizeof(SalesRecord)) {
                storageMarkAccessError();
                ok = false;
                break;
            }
            remained = true;
            continue;
        }

        if (n == 0) {
            break;
        }

        storageMarkAccessError();
        ok = false;
        break;
    }

    tmp.flush();
    tmp.close();
    src.close();

    if (!ok) {
        SD.remove(TEMP_REWRITE_FILE);
        return false;
    }

    if (!SD.remove(fileName)) {
        SD.remove(TEMP_REWRITE_FILE);
        storageMarkAccessError();
        return false;
    }

    if (remained) {
        File src2 = SD.open(TEMP_REWRITE_FILE, FILE_READ);
        if (!src2) {
            SD.remove(TEMP_REWRITE_FILE);
            storageMarkAccessError();
            return false;
        }

        File dst = SD.open(fileName, FILE_WRITE);
        if (!dst) {
            src2.close();
            SD.remove(TEMP_REWRITE_FILE);
            storageMarkAccessError();
            return false;
        }

        while (true) {
            int n = src2.read((uint8_t*)&rec, sizeof(SalesRecord));
            if (n == sizeof(SalesRecord)) {
                if (dst.write((const uint8_t*)&rec, sizeof(SalesRecord)) != sizeof(SalesRecord)) {
                    storageMarkAccessError();
                    ok = false;
                    break;
                }
                continue;
            }

            if (n == 0) {
                break;
            }

            storageMarkAccessError();
            ok = false;
            break;
        }

        dst.flush();
        dst.close();
        src2.close();
    }

    if (!SD.remove(TEMP_REWRITE_FILE)) {
        storageMarkAccessError();
        ok = false;
    }

    if (removedAny != NULL) *removedAny = removed;
    if (remainedAny != NULL) *remainedAny = remained;

    return ok;
}

static bool fileContainsTimestamp(const char* fileName, const SalesRecord* target, bool* found) {
    if (found != NULL) *found = false;
    if (fileName == NULL || target == NULL) return false;
    if (!SD.exists(fileName)) return true;

    File src = SD.open(fileName, FILE_READ);
    if (!src) {
        storageMarkAccessError();
        return false;
    }

    bool ok = true;
    SalesRecord rec;
    while (true) {
        int n = src.read((uint8_t*)&rec, sizeof(SalesRecord));
        if (n == sizeof(SalesRecord)) {
            if (sameTimestamp(&rec, target)) {
                if (found != NULL) *found = true;
                break;
            }
            continue;
        }

        if (n == 0) {
            break;
        }

        storageMarkAccessError();
        ok = false;
        break;
    }

    src.close();
    return ok;
}

static bool appendRecordToFile(const char* fileName,
                               const SalesRecord* record,
                               uint8_t isHoliday,
                               uint8_t hour,
                               uint8_t tempZone,
                               uint8_t lightZone) {
    if (fileName == NULL || record == NULL) return false;

    File file = SD.open(fileName, FILE_WRITE);
    if (!file) {
        clearFileCacheBit(isHoliday, hour, tempZone, lightZone);
        storageMarkAccessError();
        return false;
    }

    bool ok = false;
    if (file.seek(file.size())) {
        ok = file.write((const uint8_t*)record, sizeof(SalesRecord)) == sizeof(SalesRecord);
        file.flush();
    } else {
        storageMarkAccessError();
    }

    file.close();

    if (ok) {
        setFileCacheBit(isHoliday, hour, tempZone, lightZone);
    } else {
        storageMarkAccessError();
    }
    return ok;
}

static bool removeTimestampFromAllConditionFiles(const SalesRecord* record) {
    if (record == NULL || record->hour > 23) return false;

    bool ok = true;
    char fileName[13];

    for (uint8_t hFlag = 0; hFlag < 2; hFlag++) {
        for (uint8_t tz = 1; tz <= 4; tz++) {
            for (uint8_t lz = 1; lz <= 3; lz++) {
                /*
                   Trust the boot-time fileCache plus set/clear updates during
                   normal operation.  If the bit is clear, the condition file is
                   treated as absent and no SD.exists()/SD.open() probe is made.
                   This keeps auto-save from touching every possible T/L file for
                   the same hour.  If files are changed externally while powered,
                   use the existing SD_MISSING/D retry path or reboot to rebuild
                   the cache.
                */
                if (!isFileCacheBitSet(hFlag, record->hour, tz, lz)) {
                    continue;
                }

                buildSalesFileName(fileName, sizeof(fileName), hFlag, record->hour, tz, lz);

                bool found = false;
                if (!fileContainsTimestamp(fileName, record, &found)) {
                    ok = false;
                    continue;
                }

                if (!found) {
                    continue;
                }

                bool removed = false;
                bool remained = false;
                if (!rewriteFileWithoutTimestamp(fileName, record, &removed, &remained)) {
                    ok = false;
                    continue;
                }
                if (removed && !remained) {
                    clearFileCacheBit(hFlag, record->hour, tz, lz);
                }
            }
        }
    }

    return ok;
}

bool upsertLatestRecord(const char* fileName, const SalesRecord* record,
                        uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone) {
    if (fileName == NULL || record == NULL) return false;
    if (!isOpenHour(record->hour)) return true;

    if (!removeTimestampFromAllConditionFiles(record)) {
        return false;
    }

    return appendRecordToFile(fileName, record, isHoliday, hour, tempZone, lightZone);
}

bool saveGeneratedInitRecordToSalesFile(const SalesRecord* record,
                                        uint8_t isHoliday,
                                        uint8_t tempZone,
                                        uint8_t lightZone) {
    if (record == NULL) return false;
    if (!isOpenHour(record->hour)) return true;

    char fileName[13];
    buildSalesFileName(fileName, sizeof(fileName), isHoliday, record->hour, tempZone, lightZone);

    /*
       Demo and initial-generation path: append generated records directly.
       The RESET flow clears W/H files before generation, so duplicate timestamps are not expected.
       Later real auto/manual saves still call upsertLatestRecord(), which removes the same timestamp
       from all condition files before writing the real measured record.
       This avoids rewriting growing condition files 8760 times during the 1-year generation demo.
    */
    return appendRecordToFile(fileName, record, isHoliday, record->hour, tempZone, lightZone);
}

bool executeAutoSaveFromAccumulator(const HourlyAccumulator* acc, uint8_t menuA, uint8_t menuB, uint8_t menuC) {
    if (acc == NULL) return false;

#ifndef AUTO_SAVE_MIN_SENSOR_SAMPLES
#define AUTO_SAVE_MIN_SENSOR_SAMPLES 1
#endif

    /*
       Normal monitoring auto-save should still write a record during short
       demo/test windows such as uploading at 17:59 and expecting a save at
       18:00.  RESET 72-hour collection still uses MIN_SENSOR_SAMPLES_PER_HOUR
       in the main sketch, so this relaxation affects only ordinary hourly
       auto-save.
    */
    if (acc->sampleCount < AUTO_SAVE_MIN_SENSOR_SAMPLES) {
        return false;
    }

    SalesRecord record;
    record.yearOffset = acc->yearOffset;
    record.month = acc->month;
    record.day = acc->day;
    record.hour = acc->hour;
    record.airTemp10 = (int16_t)(acc->airSum / (int32_t)acc->sampleCount);
    record.humidity2 = (uint8_t)(acc->humSum / acc->sampleCount);
    record.floorTemp10 = (int16_t)(acc->floorSum / (int32_t)acc->sampleCount);
    record.cdsValue = (uint16_t)(acc->cdsSum / acc->sampleCount);
    record.irValue = (uint16_t)(acc->irSum / acc->sampleCount);
    record.menuA = menuA;
    record.menuB = menuB;
    record.menuC = menuC;

    if (!isOpenHour(record.hour)) {
        return true;
    }

    uint8_t saveTempZone = getTempZone(record.airTemp10);
    uint8_t saveLightZone = getLightZone(record.cdsValue);
    char saveFileName[13];
    buildSalesFileName(saveFileName,
                       sizeof(saveFileName),
                       acc->activeIsHoliday,
                       record.hour,
                       saveTempZone,
                       saveLightZone);

    return upsertLatestRecord(saveFileName,
                              &record,
                              acc->activeIsHoliday,
                              record.hour,
                              saveTempZone,
                              saveLightZone);
}

bool executeManualSave(uint8_t menuType, uint8_t saleCount,
                       const SalesRecord* timestampRecord,
                       const char* preferredFileName,
                       uint8_t isHoliday, uint8_t tempZone, uint8_t lightZone) {
    if (timestampRecord == NULL || saleCount == 0) return false;

    SalesRecord record = *timestampRecord;

    if (menuType == 'A') record.menuA = satAddU8(record.menuA, saleCount);
    else if (menuType == 'B') record.menuB = satAddU8(record.menuB, saleCount);
    else if (menuType == 'C') record.menuC = satAddU8(record.menuC, saleCount);
    else return false;

    char generated[13];
    const char* targetFile = preferredFileName;
    if (targetFile == NULL || targetFile[0] == '\0') {
        buildSalesFileName(generated, sizeof(generated), isHoliday, record.hour, tempZone, lightZone);
        targetFile = generated;
    }

    return upsertLatestRecord(targetFile, &record, isHoliday, record.hour, tempZone, lightZone);
}

static bool removeFileIfPresent(const char* fileName) {
    if (fileName == NULL || fileName[0] == '\0') return false;
    if (!SD.exists(fileName)) return true;
    if (SD.remove(fileName)) return true;

    /*
       If the card itself disappeared, report an access error.  If the card is
       still alive but the file could not be removed, return false so the caller
       can warn the user instead of silently assuming a clean reset.
    */
    if (!storageQuickCheck()) {
        storageMarkAccessError();
    }
    return false;
}

bool resetSalesDataOnly(void) {
    char fileName[13];
    bool ok = true;

    /*
       Fast reset path.  The full file cache is rebuilt at boot/SD retry and is
       updated after every append/delete.  Therefore reset does not need to ask
       the SD card about all 576 possible W/H files.  It removes only cached
       existing W/H files and clears each bit immediately.

       This removes the major speed variation caused by:
       - 576 SD.exists() checks before deletion
       - another 576 SD.exists() checks inside rebuildFileCache() after deletion
    */
    for (uint8_t hFlag = 0; hFlag < 2; hFlag++) {
        for (uint8_t hour = 0; hour < 24; hour++) {
            for (uint8_t tz = 1; tz <= 4; tz++) {
                for (uint8_t lz = 1; lz <= 3; lz++) {
                    if (!isFileCacheBitSet(hFlag, hour, tz, lz)) {
                        continue;
                    }

                    buildSalesFileName(fileName, sizeof(fileName), hFlag, hour, tz, lz);
                    if (SD.remove(fileName)) {
                        clearFileCacheBit(hFlag, hour, tz, lz);
                        continue;
                    }

                    if (storageQuickCheck()) {
                        /* Cache was stale or the file was already absent. */
                        clearFileCacheBit(hFlag, hour, tz, lz);
                    } else {
                        storageMarkAccessError();
                        ok = false;
                    }
                }
            }
        }
    }

    if (!removeFileIfPresent(INIT_RECORD_FILE)) ok = false;
    if (!removeFileIfPresent(INIT_STATUS_FILE)) ok = false;
    if (!removeFileIfPresent(RESET_COLLECT_FILE)) ok = false;
    if (!removeFileIfPresent(TEMP_REWRITE_FILE)) ok = false;

    /*
       After reset, no W/H sales files should remain from this runtime's known
       set.  Do not rebuild the cache here; rebuilding would reintroduce the
       slow 576-file scan immediately after deleting the files.
    */
    clearFileCache();
    return ok;
}


static bool ensureResetFolder(void) {
    if (SD.exists(RESET_DIR)) return true;
    bool ok = SD.mkdir(RESET_DIR);
    if (!ok) storageMarkAccessError();
    return ok;
}

bool clearResetCollectData(void) {
    bool ok = true;
    if (SD.exists(RESET_COLLECT_FILE)) {
        if (!SD.remove(RESET_COLLECT_FILE)) { storageMarkAccessError(); ok = false; }
    }
    return ok;
}

bool resetCollectBegin(void) {
    if (!ensureResetFolder()) return false;
    return clearResetCollectData();
}

bool appendResetCollectRecord(const SalesRecord* record) {
    if (record == NULL) return false;
    if (!ensureResetFolder()) return false;

    File file = SD.open(RESET_COLLECT_FILE, FILE_WRITE);
    if (!file) { storageMarkAccessError(); return false; }
    bool ok = false;
    if (file.seek(file.size())) {
        ok = file.write((const uint8_t*)record, sizeof(SalesRecord)) == sizeof(SalesRecord);
        file.flush();
    } else {
        storageMarkAccessError();
    }
    file.close();
    if (!ok) storageMarkAccessError();
    return ok;
}

uint16_t countResetCollectRecords(void) {
    if (!SD.exists(RESET_COLLECT_FILE)) return 0;
    File file = SD.open(RESET_COLLECT_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return 0; }
    uint32_t size = file.size();
    file.close();
    if ((size % sizeof(SalesRecord)) != 0) {
        size -= (size % sizeof(SalesRecord));
    }
    uint32_t n = size / sizeof(SalesRecord);
    if (n > 65535UL) n = 65535UL;
    return (uint16_t)n;
}

bool readResetCollectRecordAt(uint16_t index, SalesRecord* out) {
    if (out == NULL) return false;
    File file = SD.open(RESET_COLLECT_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return false; }
    uint32_t pos = (uint32_t)index * (uint32_t)sizeof(SalesRecord);
    bool ok = false;
    if (file.seek(pos)) {
        ok = file.read((uint8_t*)out, sizeof(SalesRecord)) == sizeof(SalesRecord);
    }
    file.close();
    if (!ok) storageMarkAccessError();
    return ok;
}

bool appendInitRecord(const SalesRecord* record) {
    if (record == NULL) return false;
    File file = SD.open(INIT_RECORD_FILE, FILE_WRITE);
    if (!file) { storageMarkAccessError(); return false; }
    if (!file.seek(file.size())) {
        file.close();
        storageMarkAccessError();
        return false;
    }
    size_t written = file.write((const uint8_t*)record, sizeof(SalesRecord));
    file.flush();
    file.close();
    if (written != sizeof(SalesRecord)) storageMarkAccessError();
    return written == sizeof(SalesRecord);
}

static uint8_t calcInitStatusChecksum(const InitStatusRecord* st) {
    if (st == NULL) return 0;
    InitStatusRecord tmp = *st;
    tmp.checksum = 0;
    return xorChecksumBytes((const uint8_t*)&tmp, sizeof(InitStatusRecord));
}

bool isInitStatusValid(const InitStatusRecord* st) {
    if (st == NULL) return false;
    if (st->version != 1) return false;
    if (st->totalGenerateCount != INIT_GENERATE_RECORDS_TOTAL) return false;
    if (st->phase > 3) return false;
    return calcInitStatusChecksum(st) == st->checksum;
}

bool saveInitStatus(const InitStatusRecord* st) {
    if (st == NULL) return false;

    InitStatusRecord out = *st;
    out.checksum = calcInitStatusChecksum(&out);

    /*
       INITSTAT.BIN is a single 16-byte status record.
       Do not rely on FILE_WRITE + seek(0), because some SD libraries append.
       Replace the file so loadInitStatus() never reads a stale first record.
    */
    if (SD.exists(INIT_STATUS_FILE)) {
        if (!SD.remove(INIT_STATUS_FILE)) { storageMarkAccessError(); return false; }
    }

    File file = SD.open(INIT_STATUS_FILE, FILE_WRITE);
    if (!file) { storageMarkAccessError(); return false; }

    size_t written = file.write((const uint8_t*)&out, sizeof(InitStatusRecord));
    file.flush();
    file.close();
    if (written != sizeof(InitStatusRecord)) storageMarkAccessError();
    return written == sizeof(InitStatusRecord);
}

bool loadInitStatus(InitStatusRecord* st) {
    if (st == NULL) return false;
    if (!SD.exists(INIT_STATUS_FILE)) return false;
    File file = SD.open(INIT_STATUS_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return false; }
    bool ok = file.read((uint8_t*)st, sizeof(InitStatusRecord)) == sizeof(InitStatusRecord);
    file.close();
    if (!ok) { storageMarkAccessError(); return false; }
    return isInitStatusValid(st);
}

uint16_t recoverGenerateIndexFromInitRecordFile(void) {
    if (!SD.exists(INIT_RECORD_FILE)) return 0;
    File file = SD.open(INIT_RECORD_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return 0; }
    uint32_t size = file.size();
    file.close();
    if ((size % sizeof(SalesRecord)) != 0) return 0;
    uint32_t count = size / sizeof(SalesRecord);
    if (count > INIT_GENERATE_RECORDS_TOTAL) count = INIT_GENERATE_RECORDS_TOTAL;
    return (uint16_t)count;
}

bool isInitFallbackAvailable(void) {
    InitStatusRecord st;
    if (!loadInitStatus(&st)) return false;
    if (st.phase != 3 || st.isComplete != 1) return false;
    if (!SD.exists(INIT_RECORD_FILE)) return false;

    File file = SD.open(INIT_RECORD_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return false; }
    uint32_t expected = (uint32_t)INIT_GENERATE_RECORDS_TOTAL * (uint32_t)sizeof(SalesRecord);
    uint32_t actual = file.size();
    file.close();

    return actual >= expected;
}

bool readInitRecordAt(uint16_t recordIndex, SalesRecord* out) {
    if (out == NULL) return false;
    File file = SD.open(INIT_RECORD_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return false; }
    uint32_t pos = (uint32_t)recordIndex * (uint32_t)sizeof(SalesRecord);
    bool ok = false;
    if (file.seek(pos)) {
        ok = file.read((uint8_t*)out, sizeof(SalesRecord)) == sizeof(SalesRecord);
    } else {
        storageMarkAccessError();
    }
    file.close();
    if (!ok) storageMarkAccessError();
    return ok;
}

bool readWeightHeader(WeightHeader* header) {
    if (header == NULL) return false;
    File file = SD.open(WEIGHT_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return false; }
    bool ok = file.read((uint8_t*)header, sizeof(WeightHeader)) == sizeof(WeightHeader);
    file.close();
    if (!ok) {
        storageMarkAccessError();
        return false;
    }
    return isWeightHeaderValid(header);
}

bool isWeightHeaderValid(const WeightHeader* header) {
    if (header == NULL) return false;
    if (header->magic[0] != 'W' || header->magic[1] != 'G' || header->magic[2] != 'T' || header->magic[3] != '1') return false;
    if (header->version != 1) return false;
    if (header->recordSize != sizeof(WeightRecord)) return false;
    if (header->recordCount != INIT_GENERATE_RECORDS_TOTAL) return false;
    return true;
}

bool isWeightRecordValid(const WeightRecord* record) {
    if (record == NULL) return false;
    if (record->hour > 23) return false;
    if (record->month < 1 || record->month > 12) return false;
    if (record->day < 1 || record->day > 31) return false;
    if (record->tempZone < 1 || record->tempZone > 4) return false;
    if (record->lightZone < 1 || record->lightZone > 3) return false;
    if (record->cdsValue > 1023 || record->irValue > 1023) return false;

    const uint8_t* p = (const uint8_t*)record;
    uint8_t cs = 0;
    for (uint8_t i = 0; i < sizeof(WeightRecord) - 1; i++) {
        cs ^= p[i];
    }
    return cs == record->checksum;
}

bool readWeightRecordByIndex(uint16_t index, WeightRecord* out) {
    if (out == NULL) return false;
    WeightHeader header;
    if (!readWeightHeader(&header)) return false;
    if (index >= header.recordCount) return false;

    File file = SD.open(WEIGHT_FILE, FILE_READ);
    if (!file) { storageMarkAccessError(); return false; }

    uint32_t pos = (uint32_t)sizeof(WeightHeader) + (uint32_t)index * (uint32_t)sizeof(WeightRecord);
    bool ok = false;
    if (file.seek(pos)) {
        ok = file.read((uint8_t*)out, sizeof(WeightRecord)) == sizeof(WeightRecord);
    } else {
        storageMarkAccessError();
    }
    file.close();
    if (!ok) {
        storageMarkAccessError();
        return false;
    }
    return isWeightRecordValid(out);
}

static bool weightDayIndex365(uint8_t yearOffset, uint8_t month, uint8_t day, uint16_t* outDayIndex) {
    if (outDayIndex == NULL) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > daysInMonth(yearOffset, month)) return false;

    uint16_t doy = dayOfYear(yearOffset, month, day);

    /*
       WEIGHT.BIN is a normal-year table with 365 * 24 records.
       When the generated target calendar crosses a leap year, direct dayOfYear()
       can produce 365 on Dec 31 or shift every date after Feb 29 by one day.
       Map leap-year dates onto the 365-day weight table:
       - Feb 29 reuses Feb 28's seasonal weight.
       - Dates after Feb 29 subtract one day.
    */
    if (isLeapYearOffset(yearOffset)) {
        if (month == 2 && day == 29) {
            doy = dayOfYear(yearOffset, 2, 28);
        } else if (month > 2) {
            if (doy == 0) return false;
            doy--;
        }
    }

    if (doy >= 365U) return false;
    *outDayIndex = doy;
    return true;
}

bool readWeightRecordByTargetDate(uint8_t yearOffset, uint8_t month, uint8_t day, uint8_t hour, WeightRecord* out) {
    if (out == NULL) return false;
    if (hour > 23) return false;

    uint16_t dayIndex = 0;
    if (!weightDayIndex365(yearOffset, month, day, &dayIndex)) return false;

    uint16_t index = (uint16_t)(dayIndex * 24U + hour);
    if (!readWeightRecordByIndex(index, out)) return false;

    if (out->hour != hour) return false;
    if (out->dayIndex != dayIndex) return false;
    return true;
}
