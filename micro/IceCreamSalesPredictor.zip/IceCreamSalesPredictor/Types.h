#ifndef TYPES_H
#define TYPES_H

#include <Arduino.h>
#include <stdint.h>

struct __attribute__((packed)) SalesRecord {
    uint8_t yearOffset;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    int16_t airTemp10;
    uint8_t humidity2;
    int16_t floorTemp10;
    uint16_t cdsValue;
    uint16_t irValue;
    uint8_t menuA;
    uint8_t menuB;
    uint8_t menuC;
};

typedef char SalesRecordSizeCheck[(sizeof(SalesRecord) == 16) ? 1 : -1];

enum SystemState : uint8_t {
    STATE_MONITORING,
    STATE_PREDICT_INPUT,
    STATE_MANUAL_INPUT,
    STATE_HOLIDAY_INPUT,
    STATE_RESET_CONFIRM,
    STATE_INIT_COLLECT,
    STATE_INIT_GENERATE,
    STATE_SD_MISSING
};

enum PredictionMode : uint8_t {
    PREDICT_IMMEDIATE = 0,
    PREDICT_FUTURE_CURRENT_ENV = 1,
    PREDICT_FUTURE_TARGET_ENV = 2
};

enum ConfidenceLevel : uint8_t {
    CONF_NONE = 0,
    CONF_LOW  = 1,
    CONF_MED  = 2,
    CONF_HIGH = 3
};

struct PredictionContext {
    uint8_t yearOffset;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t dayOfWeek;
    uint8_t isHoliday;
    int16_t airTemp10;
    uint8_t humidity2;
    int16_t floorTemp10;
    uint16_t cdsValue;
    uint16_t irValue;
    uint8_t mode;
};

struct PredictResult {
    uint8_t menuA;
    uint8_t menuB;
    uint8_t menuC;
    uint8_t confidenceLevel;
    uint8_t usedCount;
    uint8_t maxStageUsed;
    bool lowDataFlag;
    bool valid;
};

struct HourlyAccumulator {
    uint8_t yearOffset;
    uint8_t month;
    uint8_t day;
    uint8_t hour;

    int32_t airSum;
    uint32_t humSum;
    int32_t floorSum;
    uint32_t cdsSum;
    uint32_t irSum;
    uint16_t sampleCount;

    char activeFileName[13];
    uint8_t activeIsHoliday;
    uint8_t activeTempZone;
    uint8_t activeLightZone;
};

struct __attribute__((packed)) InitStatusRecord {
    uint8_t phase;
    uint8_t startYearOffset;
    uint8_t startMonth;
    uint8_t startDay;
    uint16_t collectHoursDone;
    uint16_t generateIndex;
    uint16_t totalGenerateCount;
    uint8_t isComplete;
    uint8_t version;
    uint8_t checksum;
    uint8_t reserved[3];
};

typedef char InitStatusRecordSizeCheck[(sizeof(InitStatusRecord) == 16) ? 1 : -1];

struct __attribute__((packed)) WeightHeader {
    char magic[4];
    uint8_t version;
    uint8_t recordSize;
    uint16_t recordCount;
    uint8_t baseYearOffset;
    uint8_t flags;
    uint8_t reserved[6];
};

struct __attribute__((packed)) WeightRecord {
    uint16_t dayIndex;

    int16_t airTemp10;
    int16_t floorTemp10;
    uint16_t cdsValue;
    uint16_t irValue;

    int16_t totalOffset;

    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t dayOfWeek;
    uint8_t flags;
    uint8_t tempZone;
    uint8_t lightZone;
    uint8_t humidity2;

    int8_t yearW;
    int8_t dateW;
    int8_t hourW;
    int8_t dowW;
    int8_t holidayW;
    int8_t tempW;
    int8_t humW;
    int8_t lightW;
    int8_t floorW;

    uint8_t reserved[2];
    uint8_t checksum;
};

typedef char WeightHeaderSizeCheck[(sizeof(WeightHeader) == 16) ? 1 : -1];
typedef char WeightRecordSizeCheck[(sizeof(WeightRecord) == 32) ? 1 : -1];

struct DateTimeParts {
    uint8_t yearOffset;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    uint8_t dayOfWeek;
};

struct SensorSnapshot {
    int16_t airTemp10;
    uint8_t humidity2;
    int16_t floorTemp10;
    uint16_t cdsValue;
    uint16_t irValue;
    bool valid;
};

static inline uint8_t satAddU8(uint8_t cur, uint8_t add) {
    return (uint8_t)((255 - cur < add) ? 255 : (cur + add));
}

static inline uint8_t clampU8FromU16(uint16_t v) {
    return (v > 255U) ? 255U : (uint8_t)v;
}

static inline uint16_t absDiff16(int32_t a, int32_t b) {
    return (uint16_t)((a > b) ? (a - b) : (b - a));
}

#endif
