#ifndef PREDICTION_H
#define PREDICTION_H

#include <Arduino.h>
#include "Types.h"

bool executePredictOneHour(const PredictionContext* ctx, PredictResult* out);
bool executePredictRange(const PredictionContext* baseCtx, uint8_t startHour, uint8_t endHour,
                         uint16_t* outA, uint16_t* outB, uint16_t* outC,
                         uint8_t* outConfidence, uint8_t* outUsed, uint8_t* outMaxStage);

#endif
