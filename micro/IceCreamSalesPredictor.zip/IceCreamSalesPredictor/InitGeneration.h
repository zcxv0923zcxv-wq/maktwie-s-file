#ifndef INIT_GENERATION_H
#define INIT_GENERATION_H

#include <Arduino.h>
#include "Types.h"

void initGenerationResetRuntime(void);
void beginInitCollectFromReset(InitStatusRecord* st, const DateTimeParts* now);
bool updateInitCollectProgressOnHourSaved(InitStatusRecord* st);
bool tryImportExternalInitData(InitStatusRecord* st);
bool prepareInitGeneration(InitStatusRecord* st);
bool generateNextInitRecord(InitStatusRecord* st);
bool isInitGenerationComplete(const InitStatusRecord* st);
uint8_t currentInitCollectDay(const InitStatusRecord* st);

#endif
