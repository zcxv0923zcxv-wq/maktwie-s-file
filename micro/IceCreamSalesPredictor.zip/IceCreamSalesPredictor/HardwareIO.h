#ifndef HARDWARE_IO_H
#define HARDWARE_IO_H

#include <Arduino.h>
#include "Types.h"

enum OwnerKeyEventType : uint8_t {
    OWNER_KEY_NONE = 0,
    OWNER_KEY_NORMAL = 1,
    OWNER_KEY_D_SHORT = 2,
    OWNER_KEY_D_LONG = 3
};

struct OwnerKeyEvent {
    OwnerKeyEventType type;
    char key;
};

void hardwareBegin(void);

bool readKioskMenuAEdge(void);
bool readKioskMenuBEdge(void);
bool readKioskMenuCEdge(void);
bool readKioskConfirmEdge(void);
bool readKioskResetEdge(void);

OwnerKeyEvent readOwnerKeyEvent(void);

bool readRtcDateTime(DateTimeParts* out);
bool readSensors(SensorSnapshot* out);

void setLedMonitoring(void);
void setLedInput(void);
void setLedError(void);
void setLedOff(void);
void blinkGreenOnce(void);
void blinkBlueOnce(void);
void blinkRedOnce(void);

void showOwnerMessage(const __FlashStringHelper* line1, const __FlashStringHelper* line2);
void showOwnerText(const char* line1, const char* line2);
void showOwnerSales(uint8_t hour, uint8_t minute, uint8_t a, uint8_t b, uint8_t c);
void showOwnerPrediction(uint16_t a, uint16_t b, uint16_t c, uint8_t conf, uint8_t used);
void showKioskOrder(uint8_t a, uint8_t b, uint8_t c);
void showKioskSaved(void);
void showKioskReset(void);
void showInitCollect(uint8_t dayNum);
void showInitCollectStatus(uint16_t done, uint16_t total, uint8_t hour, uint8_t minute, uint8_t a, uint8_t b, uint8_t c);
void showInitMake(uint16_t done, uint16_t total);
void showInitDone(void);
void showResetConfirm(void);

#endif
