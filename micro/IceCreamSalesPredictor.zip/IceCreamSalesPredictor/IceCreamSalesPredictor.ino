#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include <LiquidCrystal.h>
#include <Keypad.h>
#include <DHT.h>
#include <avr/pgmspace.h>

#include "Types.h"
#include "HardwareConfig.h"
#include "Utils.h"
#include "HardwareIO.h"
#include "Storage.h"
#include "Prediction.h"
#include "InitGeneration.h"

SystemState currentState = STATE_MONITORING;

uint8_t current_hour_menuA = 0;
uint8_t current_hour_menuB = 0;
uint8_t current_hour_menuC = 0;

uint8_t kioskTempMenuA = 0;
uint8_t kioskTempMenuB = 0;
uint8_t kioskTempMenuC = 0;

uint8_t lastTrackedYearOffset = 0;
uint8_t lastTrackedMonth = 0;
uint8_t lastTrackedDay = 0;
uint8_t lastTrackedHour = 99;

HourlyAccumulator hourAcc;

uint8_t autoSaveHolidayFlag = 0;
uint8_t pendingHolidayInput = HOLIDAY_INPUT_NONE;
uint8_t pendingResetInput = RESET_INPUT_NONE;

InitStatusRecord initStatus;

uint32_t lastSensorSampleMs = 0;
uint32_t lastOwnerLcdMs = 0;
uint32_t lastKioskLcdMs = 0;
uint32_t lastLiveSensorReadMs = 0;
uint32_t lastSerialDebugMs = 0;
bool storageReady = false;
bool initGenerateCancelRequested = false;

SensorSnapshot lastSensor = {250, 100, 250, 512, 512, false};
DateTimeParts currentRtc = {26, 1, 1, 0, 0, 0, 3};
uint32_t lastSoftwareClockMs = 0;
bool rtcReadOk = false;

#define PENDING_AUTO_SAVE_CAPACITY 8

struct PendingAutoSaveEntry {
    bool valid;
    bool needsSensor;
    SalesRecord record;
    uint8_t isHoliday;
    uint8_t tempZone;
    uint8_t lightZone;
};

PendingAutoSaveEntry pendingAutoSaves[PENDING_AUTO_SAVE_CAPACITY];
uint32_t lastPendingAutoRetryMs = 0;
const uint32_t PENDING_AUTO_RETRY_INTERVAL_MS = 5000UL;

static bool refreshStorageNow(bool showStatus);
static bool storageReadyQuickCheck(void);
static bool handleStorageAccessFailureAfterOperation(bool initCollectContext);
static void enterMonitoringState(void);
static void enterSdMissingState(void);
static void showInitCollectSdMissingTemp(void);
static bool handleInitCollectSdCheck(void);
static void requestInitGenerateCancel(void);
static void finishInitGenerateCancel(void);
static void ensureAutoSaveHasSensorSample(void);
static void showAutoSaveResultMessage(bool saved, bool openHour, uint8_t savedHour, uint8_t a, uint8_t b, uint8_t c);
static int8_t enqueuePendingAutoSaveFromAccumulator(const HourlyAccumulator* acc, uint8_t menuA, uint8_t menuB, uint8_t menuC);
static bool retryPendingAutoSaves(bool showStatus);
static void clearPendingAutoSaves(void);
static bool pendingAutoSaveStillValid(uint8_t index);
static bool appendResetCollectFromAccumulator(const HourlyAccumulator* acc, uint8_t menuA, uint8_t menuB, uint8_t menuC);

static void setSoftwareClockFromUploadConfig(void) {
    uint16_t fullYear = RTC_SET_YEAR_FULL;
    if (fullYear < 2000U) fullYear = 2000U;
    if (fullYear > 2099U) fullYear = 2099U;

    currentRtc.yearOffset = (uint8_t)(fullYear - 2000U);
    currentRtc.month = constrain((int)RTC_SET_MONTH, 1, 12);
    currentRtc.day = constrain((int)RTC_SET_DAY, 1, (int)daysInMonth(currentRtc.yearOffset, currentRtc.month));
    currentRtc.hour = constrain((int)RTC_SET_HOUR, 0, 23);
    currentRtc.minute = constrain((int)RTC_SET_MINUTE, 0, 59);
    currentRtc.second = constrain((int)RTC_SET_SECOND, 0, 59);
    currentRtc.dayOfWeek = getDayOfWeek(currentRtc.yearOffset, currentRtc.month, currentRtc.day);
}

enum PredictInputStage : uint8_t {
    PRED_STAGE_MENU,
    PRED_STAGE_DATE,
    PRED_STAGE_START,
    PRED_STAGE_END
};

PredictInputStage predStage = PRED_STAGE_MENU;
char inputBuffer[9];
uint8_t inputLen = 0;
uint8_t predYearOffset = 0;
uint8_t predMonth = 0;
uint8_t predDay = 0;
uint8_t predStartHour = 0;
uint8_t predEndHour = 0;
char predMenu = 0;

char manualMenu = 0;
uint8_t manualCount = 0;

static void clearInputBuffer(void) {
    for (uint8_t i = 0; i < sizeof(inputBuffer); i++) inputBuffer[i] = '\0';
    inputLen = 0;
}

static void appendDigitToInput(char key, uint8_t maxLen) {
    if (key < '0' || key > '9') return;
    if (inputLen >= maxLen) return;
    inputBuffer[inputLen++] = key;
    inputBuffer[inputLen] = '\0';
}

static uint16_t parseInputU16(void) {
    uint16_t v = 0;
    for (uint8_t i = 0; i < inputLen; i++) {
        if (inputBuffer[i] < '0' || inputBuffer[i] > '9') break;
        v = (uint16_t)(v * 10U + (uint16_t)(inputBuffer[i] - '0'));
    }
    return v;
}

static void resetPredictInput(void) {
    predStage = PRED_STAGE_MENU;
    clearInputBuffer();
    predYearOffset = 0;
    predMonth = 0;
    predDay = 0;
    predStartHour = 0;
    predEndHour = 0;
    predMenu = 0;
}

static void resetManualInput(void) {
    manualMenu = 0;
    manualCount = 0;
    clearInputBuffer();
}

static void resetHolidayInput(void) {
    pendingHolidayInput = HOLIDAY_INPUT_NONE;
}

static void resetResetInput(void) {
    pendingResetInput = RESET_INPUT_NONE;
}

static void buildCurrentAccumulatorFileName(void) {
    hourAcc.activeTempZone = getTempZone(lastSensor.airTemp10);
    hourAcc.activeLightZone = getLightZone(lastSensor.cdsValue);
    buildSalesFileName(hourAcc.activeFileName,
                       sizeof(hourAcc.activeFileName),
                       hourAcc.activeIsHoliday,
                       hourAcc.hour,
                       hourAcc.activeTempZone,
                       hourAcc.activeLightZone);
}

static void beginNewHourlyAccumulator(const DateTimeParts* now) {
    if (now == NULL) return;

    hourAcc.yearOffset = now->yearOffset;
    hourAcc.month = now->month;
    hourAcc.day = now->day;
    hourAcc.hour = now->hour;
    hourAcc.airSum = 0;
    hourAcc.humSum = 0;
    hourAcc.floorSum = 0;
    hourAcc.cdsSum = 0;
    hourAcc.irSum = 0;
    hourAcc.sampleCount = 0;
    hourAcc.activeIsHoliday = autoSaveHolidayFlag;
    buildCurrentAccumulatorFileName();

    lastTrackedYearOffset = now->yearOffset;
    lastTrackedMonth = now->month;
    lastTrackedDay = now->day;
    lastTrackedHour = now->hour;
}

static void accumulateSensorSample(const SensorSnapshot* s) {
    if (s == NULL || !s->valid) return;

    hourAcc.airSum += s->airTemp10;
    hourAcc.humSum += s->humidity2;
    hourAcc.floorSum += s->floorTemp10;
    hourAcc.cdsSum += s->cdsValue;
    hourAcc.irSum += s->irValue;
    if (hourAcc.sampleCount < 65535U) {
        hourAcc.sampleCount++;
    }

    lastSensor = *s;
    if (hourAcc.sampleCount == 1) {
        buildCurrentAccumulatorFileName();
    }
}

static void handleSensorSampling(void) {
    uint32_t nowMs = millis();
    if ((nowMs - lastSensorSampleMs) < SENSOR_SAMPLE_INTERVAL_MS && hourAcc.sampleCount > 0) {
        return;
    }

    SensorSnapshot s;
    if (readSensors(&s) && s.valid) {
        accumulateSensorSample(&s);
        lastSensorSampleMs = nowMs;
    } else {
        showOwnerMessage(F("SENSOR ERROR"), F("CHECK LINE"));
        setLedError();
    }
}

static void resetKioskTempOrder(void) {
    kioskTempMenuA = 0;
    kioskTempMenuB = 0;
    kioskTempMenuC = 0;
}

static void resetCurrentHourSalesAndKiosk(void) {
    current_hour_menuA = 0;
    current_hour_menuB = 0;
    current_hour_menuC = 0;
    resetKioskTempOrder();
}

static bool initCollectIsWaitingFirstFullHour(void) {
    return currentState == STATE_INIT_COLLECT &&
           initStatus.phase == 1 &&
           initStatus.reserved[1] == 1;
}

static void showInitCollectProgressNow(void) {
    showInitCollectStatus(initStatus.collectHoursDone,
                          INIT_COLLECT_HOURS_TOTAL,
                          currentRtc.hour,
                          currentRtc.minute,
                          current_hour_menuA,
                          current_hour_menuB,
                          current_hour_menuC);
}

static void addKioskTempOrder(uint8_t menuType) {
    if (menuType == 'A') kioskTempMenuA = satAddU8(kioskTempMenuA, 1);
    else if (menuType == 'B') kioskTempMenuB = satAddU8(kioskTempMenuB, 1);
    else if (menuType == 'C') kioskTempMenuC = satAddU8(kioskTempMenuC, 1);
}

static bool confirmKioskTempOrder(void) {
    if (kioskTempMenuA == 0 && kioskTempMenuB == 0 && kioskTempMenuC == 0) {
        return false;
    }

    current_hour_menuA = satAddU8(current_hour_menuA, kioskTempMenuA);
    current_hour_menuB = satAddU8(current_hour_menuB, kioskTempMenuB);
    current_hour_menuC = satAddU8(current_hour_menuC, kioskTempMenuC);

    resetKioskTempOrder();
    return true;
}

static void handleKioskInput(void) {
    bool changed = false;

    if (readKioskMenuAEdge()) {
        addKioskTempOrder('A');
        changed = true;
    }
    if (readKioskMenuBEdge()) {
        addKioskTempOrder('B');
        changed = true;
    }
    if (readKioskMenuCEdge()) {
        addKioskTempOrder('C');
        changed = true;
    }
    if (readKioskResetEdge()) {
        resetKioskTempOrder();
        showKioskReset();
        blinkBlueOnce();
        return;
    }
    if (readKioskConfirmEdge()) {
        if (confirmKioskTempOrder()) {
            showKioskSaved();
            blinkGreenOnce();
            lastOwnerLcdMs = 0;
            if (currentState == STATE_INIT_COLLECT) {
                showInitCollectProgressNow();
            } else if (currentState == STATE_MONITORING) {
                showOwnerSales(currentRtc.hour, currentRtc.minute, current_hour_menuA, current_hour_menuB, current_hour_menuC);
            }
        }
        return;
    }

    if (changed) {
        showKioskOrder(kioskTempMenuA, kioskTempMenuB, kioskTempMenuC);
    }
}

static void applyHolidayFlagToCurrentAccumulator(uint8_t isHoliday) {
    autoSaveHolidayFlag = isHoliday ? 1 : 0;
    hourAcc.activeIsHoliday = autoSaveHolidayFlag;
    buildSalesFileName(hourAcc.activeFileName,
                       sizeof(hourAcc.activeFileName),
                       hourAcc.activeIsHoliday,
                       hourAcc.hour,
                       hourAcc.activeTempZone,
                       hourAcc.activeLightZone);
}

static void ensureAutoSaveHasSensorSample(void) {
    if (hourAcc.sampleCount == 0 && lastSensor.valid) {
        accumulateSensorSample(&lastSensor);
    }
}

static void showAutoSaveResultMessage(bool saved, bool openHour, uint8_t savedHour, uint8_t a, uint8_t b, uint8_t c) {
    char l1[17];
    char l2[17];

    if (saved && openHour) {
        snprintf_P(l1, sizeof(l1), PSTR("AUTO SAVE H%02u"), (unsigned)savedHour);
        snprintf_P(l2, sizeof(l2), PSTR("A%03u B%03u C%03u"),
                   (unsigned)a,
                   (unsigned)b,
                   (unsigned)c);
        showOwnerText(l1, l2);
        lastOwnerLcdMs = millis();
        return;
    }

    if (saved && !openHour) {
        snprintf_P(l1, sizeof(l1), PSTR("AUTO SKIP H%02u"), (unsigned)savedHour);
        snprintf_P(l2, sizeof(l2), PSTR("CLOSED HOUR"));
        showOwnerText(l1, l2);
        lastOwnerLcdMs = millis();
    }
}


static void fillRecordEnvFromSensor(SalesRecord* record, const SensorSnapshot* s) {
    if (record == NULL || s == NULL) return;
    record->airTemp10 = s->airTemp10;
    record->humidity2 = s->humidity2;
    record->floorTemp10 = s->floorTemp10;
    record->cdsValue = s->cdsValue;
    record->irValue = s->irValue;
}

static int8_t findPendingAutoSaveSlotByTimestamp(const SalesRecord* record) {
    if (record == NULL) return -1;
    for (uint8_t i = 0; i < PENDING_AUTO_SAVE_CAPACITY; i++) {
        if (!pendingAutoSaves[i].valid) continue;
        const SalesRecord* r = &pendingAutoSaves[i].record;
        if (r->yearOffset == record->yearOffset &&
            r->month == record->month &&
            r->day == record->day &&
            r->hour == record->hour) {
            return (int8_t)i;
        }
    }
    return -1;
}

static int8_t findEmptyPendingAutoSaveSlot(void) {
    for (uint8_t i = 0; i < PENDING_AUTO_SAVE_CAPACITY; i++) {
        if (!pendingAutoSaves[i].valid) return (int8_t)i;
    }
    return -1;
}

static bool pendingAutoSaveStillValid(uint8_t index) {
    if (index >= PENDING_AUTO_SAVE_CAPACITY) return false;
    return pendingAutoSaves[index].valid;
}

static void clearPendingAutoSaves(void) {
    for (uint8_t i = 0; i < PENDING_AUTO_SAVE_CAPACITY; i++) {
        pendingAutoSaves[i].valid = false;
        pendingAutoSaves[i].needsSensor = false;
    }
    lastPendingAutoRetryMs = 0;
}

static int8_t enqueuePendingAutoSaveFromAccumulator(const HourlyAccumulator* acc, uint8_t menuA, uint8_t menuB, uint8_t menuC) {
    if (acc == NULL) return -1;
    if (!isOpenHour(acc->hour)) return -2;

    SalesRecord record;
    record.yearOffset = acc->yearOffset;
    record.month = acc->month;
    record.day = acc->day;
    record.hour = acc->hour;
    record.menuA = menuA;
    record.menuB = menuB;
    record.menuC = menuC;

    bool needsSensor = false;
    uint8_t tempZone = acc->activeTempZone;
    uint8_t lightZone = acc->activeLightZone;

    if (acc->sampleCount > 0) {
        record.airTemp10 = (int16_t)(acc->airSum / (int32_t)acc->sampleCount);
        record.humidity2 = (uint8_t)(acc->humSum / acc->sampleCount);
        record.floorTemp10 = (int16_t)(acc->floorSum / (int32_t)acc->sampleCount);
        record.cdsValue = (uint16_t)(acc->cdsSum / acc->sampleCount);
        record.irValue = (uint16_t)(acc->irSum / acc->sampleCount);
        tempZone = getTempZone(record.airTemp10);
        lightZone = getLightZone(record.cdsValue);
    } else if (lastSensor.valid) {
        fillRecordEnvFromSensor(&record, &lastSensor);
        tempZone = getTempZone(record.airTemp10);
        lightZone = getLightZone(record.cdsValue);
    } else {
        /*
           Keep the timestamp and menu counts instead of discarding the hour.
           The first later valid sensor sample will be used only as an emergency
           environment fallback, so the sales count is not lost.
        */
        record.airTemp10 = 0;
        record.humidity2 = 0;
        record.floorTemp10 = 0;
        record.cdsValue = 0;
        record.irValue = 0;
        needsSensor = true;
        tempZone = 1;
        lightZone = 1;
    }

    int8_t slot = findPendingAutoSaveSlotByTimestamp(&record);
    if (slot < 0) {
        slot = findEmptyPendingAutoSaveSlot();
    }
    if (slot < 0) return -3;

    pendingAutoSaves[slot].valid = true;
    pendingAutoSaves[slot].needsSensor = needsSensor;
    pendingAutoSaves[slot].record = record;
    pendingAutoSaves[slot].isHoliday = acc->activeIsHoliday;
    pendingAutoSaves[slot].tempZone = tempZone;
    pendingAutoSaves[slot].lightZone = lightZone;
    return slot;
}

static bool saveOnePendingAutoSave(uint8_t index) {
    if (index >= PENDING_AUTO_SAVE_CAPACITY) return true;
    PendingAutoSaveEntry* p = &pendingAutoSaves[index];
    if (!p->valid) return true;

    if (p->needsSensor) {
        if (!lastSensor.valid) {
            return false;
        }
        fillRecordEnvFromSensor(&p->record, &lastSensor);
        p->tempZone = getTempZone(p->record.airTemp10);
        p->lightZone = getLightZone(p->record.cdsValue);
        p->needsSensor = false;
    }

    char fileName[13];
    buildSalesFileName(fileName,
                       sizeof(fileName),
                       p->isHoliday,
                       p->record.hour,
                       p->tempZone,
                       p->lightZone);

    storageClearAccessError();
    bool ok = upsertLatestRecord(fileName,
                                 &p->record,
                                 p->isHoliday,
                                 p->record.hour,
                                 p->tempZone,
                                 p->lightZone);
    if (ok) {
        p->valid = false;
        p->needsSensor = false;
        return true;
    }

    if (storageHadAccessError()) {
        if (!storageQuickCheck()) {
            storageReady = false;
            enterSdMissingState();
            return false;
        }
        storageClearAccessError();
    }

    return false;
}

static bool retryPendingAutoSaves(bool showStatus) {
    if (!storageReady) return false;

    bool hasPending = false;
    for (uint8_t i = 0; i < PENDING_AUTO_SAVE_CAPACITY; i++) {
        if (pendingAutoSaves[i].valid) {
            hasPending = true;
            break;
        }
    }
    if (!hasPending) return true;

    uint32_t nowMs = millis();
    if (!showStatus && lastPendingAutoRetryMs != 0 &&
        (nowMs - lastPendingAutoRetryMs) < PENDING_AUTO_RETRY_INTERVAL_MS) {
        return false;
    }
    lastPendingAutoRetryMs = nowMs;

    bool savedAny = false;
    bool stillPending = false;

    for (uint8_t i = 0; i < PENDING_AUTO_SAVE_CAPACITY; i++) {
        if (!pendingAutoSaves[i].valid) continue;

        bool wasValid = pendingAutoSaves[i].valid;
        if (!saveOnePendingAutoSave(i)) {
            if (currentState == STATE_SD_MISSING) {
                return false;
            }
            if (pendingAutoSaves[i].valid) {
                stillPending = true;
            }
        } else if (wasValid && !pendingAutoSaves[i].valid) {
            savedAny = true;
        }
    }

    if (savedAny && showStatus) {
        showOwnerMessage(F("PEND SAVE OK"), F("AUTO REC SAVED"));
        blinkGreenOnce();
        lastOwnerLcdMs = millis();
    }

    return !stillPending;
}

static void handleHourRollover(const DateTimeParts* now) {
    if (now == NULL) return;

    bool changed = (lastTrackedHour == 99) ||
                   now->yearOffset != lastTrackedYearOffset ||
                   now->month != lastTrackedMonth ||
                   now->day != lastTrackedDay ||
                   now->hour != lastTrackedHour;

    if (!changed) return;

    if (lastTrackedHour != 99) {
        if (currentState == STATE_INIT_GENERATE) {
            /*
               During 1-year initial generation, ordinary hourly auto-save and
               kiosk accumulation must not run.  Keep the software clock and
               accumulator aligned with real time, but do not write real sales
               records while generated W/H files are being created.
            */
            resetCurrentHourSalesAndKiosk();
            autoSaveHolidayFlag = isHolidayDate(now->yearOffset, now->month, now->day) ? 1 : 0;
            beginNewHourlyAccumulator(now);
            lastSensorSampleMs = 0;
            return;
        }

        if (initCollectIsWaitingFirstFullHour()) {
            /*
               RESET이 정각이 아닌 시점에 눌린 경우, 그 시간대는 부분 시간 데이터다.
               이 부분 시간은 72개 수집 데이터에 넣지 않고 다음 정각부터 0/72로 시작한다.
            */
            resetCurrentHourSalesAndKiosk();
            autoSaveHolidayFlag = isHolidayDate(now->yearOffset, now->month, now->day) ? 1 : 0;
            beginInitCollectFromReset(&initStatus, now);
            beginNewHourlyAccumulator(now);
            lastSensorSampleMs = 0;
            showInitCollectProgressNow();
            return;
        }

        bool saved = false;
        bool sdOk = true;
        bool savedOpenHour = isOpenHour(hourAcc.hour);
        int8_t pendingSlot = -1;
        bool pendingQueueFull = false;

        if (currentState == STATE_INIT_COLLECT) {
            sdOk = storageReadyQuickCheck();
            if (!sdOk) {
                showInitCollectSdMissingTemp();
            } else {
                saved = appendResetCollectFromAccumulator(&hourAcc,
                                                          current_hour_menuA,
                                                          current_hour_menuB,
                                                          current_hour_menuC);
            }
        } else if (!savedOpenHour) {
            /* Closed hours intentionally produce no W/H sales record. */
            saved = true;
        } else {
            ensureAutoSaveHasSensorSample();
            pendingSlot = enqueuePendingAutoSaveFromAccumulator(&hourAcc,
                                                                current_hour_menuA,
                                                                current_hour_menuB,
                                                                current_hour_menuC);
            if (pendingSlot < 0) {
                pendingQueueFull = (pendingSlot == -3);
                saved = false;
            } else {
                sdOk = storageReadyQuickCheck();
                if (!sdOk) {
                    enterSdMissingState();
                } else {
                    lastPendingAutoRetryMs = 0;
                    retryPendingAutoSaves(false);
                    if (currentState == STATE_SD_MISSING) {
                        return;
                    }
                    saved = !pendingAutoSaveStillValid((uint8_t)pendingSlot);
                }
            }
        }


        if (sdOk && !saved) {
            bool accessError = storageHadAccessError();
            if (accessError && handleStorageAccessFailureAfterOperation(currentState == STATE_INIT_COLLECT)) {
                return;
            }

            if (accessError) {
                showOwnerMessage(F("SD ERROR"), F("WRITE FAIL"));
            } else if (currentState == STATE_INIT_COLLECT) {
                showOwnerMessage(F("SAMPLE LOW"), F("INIT SKIP"));
            } else if (pendingQueueFull) {
                showOwnerMessage(F("AUTO FAIL"), F("PEND FULL"));
            } else {
                showOwnerMessage(F("AUTO WAIT"), F("NEED SENSOR"));
            }
            setLedError();
            Serial.print(F("[AUTO] FAIL sampleCount="));
            Serial.print(hourAcc.sampleCount);
            Serial.print(F(" hour="));
            Serial.print(hourAcc.hour);
            Serial.print(F(" accessError="));
            Serial.println(accessError ? 1 : 0);
        } else if (sdOk && saved) {
            blinkGreenOnce();
            Serial.print(F("[AUTO] OK hour="));
            Serial.print(hourAcc.hour);
            Serial.print(F(" samples="));
            Serial.print(hourAcc.sampleCount);
            Serial.print(F(" file="));
            Serial.println(hourAcc.activeFileName);

            if (currentState == STATE_INIT_COLLECT) {
                if (!updateInitCollectProgressOnHourSaved(&initStatus)) {
                    showOwnerMessage(F("STAT ERROR"), F("INITSTAT"));
                    setLedError();
                }
            } else {
                showAutoSaveResultMessage(saved,
                                          savedOpenHour,
                                          hourAcc.hour,
                                          current_hour_menuA,
                                          current_hour_menuB,
                                          current_hour_menuC);
            }
        }

        if (!sdOk && currentState == STATE_SD_MISSING) {
            return;
        }
    }

    resetCurrentHourSalesAndKiosk();

    autoSaveHolidayFlag = isHolidayDate(now->yearOffset, now->month, now->day) ? 1 : 0;
    beginNewHourlyAccumulator(now);
}

static void advanceCurrentRtcBySeconds(uint32_t sec) {
    while (sec > 0) {
        uint32_t remainInMinute = 60UL - currentRtc.second;
        if (remainInMinute == 0) remainInMinute = 60UL;
        uint32_t step = (sec < remainInMinute) ? sec : remainInMinute;
        currentRtc.second = (uint8_t)(currentRtc.second + step);
        sec -= step;

        if (currentRtc.second >= 60) {
            currentRtc.second = 0;
            currentRtc.minute++;
            if (currentRtc.minute >= 60) {
                currentRtc.minute = 0;
                currentRtc.hour++;
                if (currentRtc.hour >= 24) {
                    currentRtc.hour = 0;
                    currentRtc.day++;
                    if (currentRtc.day > daysInMonth(currentRtc.yearOffset, currentRtc.month)) {
                        currentRtc.day = 1;
                        currentRtc.month++;
                        if (currentRtc.month > 12) {
                            currentRtc.month = 1;
                            currentRtc.yearOffset++;
                        }
                    }
                    currentRtc.dayOfWeek = getDayOfWeek(currentRtc.yearOffset, currentRtc.month, currentRtc.day);
                }
            }
        }
    }
}

static bool updateCurrentRtc(void) {
    DateTimeParts rtcNow;
    uint32_t nowMs = millis();

    if (readRtcDateTime(&rtcNow)) {
        currentRtc = rtcNow;
        lastSoftwareClockMs = nowMs;
        rtcReadOk = true;
        return true;
    }

    rtcReadOk = false;
    if (lastSoftwareClockMs == 0) {
        lastSoftwareClockMs = nowMs;
        return true;
    }

    uint32_t elapsedSec = (nowMs - lastSoftwareClockMs) / 1000UL;
    if (elapsedSec > 0) {
        lastSoftwareClockMs += elapsedSec * 1000UL;
        advanceCurrentRtcBySeconds(elapsedSec);
    }

    return true;
}

static void handleLiveSensorRefresh(void) {
    uint32_t nowMs = millis();
    if ((nowMs - lastLiveSensorReadMs) < LIVE_SENSOR_REFRESH_INTERVAL_MS) {
        return;
    }

    SensorSnapshot s;
    if (readSensors(&s) && s.valid) {
        lastSensor = s;
        lastLiveSensorReadMs = nowMs;
    }
}

static void serialPrint2Digit(uint8_t v) {
    if (v < 10) Serial.print('0');
    Serial.print(v);
}

static void serialPrintTemp10(int16_t value10) {
    if (value10 < 0) {
        Serial.print('-');
        value10 = -value10;
    }
    Serial.print(value10 / 10);
    Serial.print('.');
    Serial.print(value10 % 10);
}

static void serialPrintHumidity2(uint8_t value2) {
    Serial.print(value2 / 2);
    if ((value2 % 2) != 0) Serial.print(F(".5"));
    else Serial.print(F(".0"));
}

static void printDebugStatusToSerial(void) {
    uint32_t nowMs = millis();
    if ((nowMs - lastSerialDebugMs) < SERIAL_DEBUG_INTERVAL_MS) {
        return;
    }
    lastSerialDebugMs = nowMs;

    Serial.print(F("[TIME] "));
    Serial.print(rtcReadOk ? F("RTC ") : F("SW "));
    Serial.print(F("20"));
    serialPrint2Digit(currentRtc.yearOffset);
    Serial.print('-');
    serialPrint2Digit(currentRtc.month);
    Serial.print('-');
    serialPrint2Digit(currentRtc.day);
    Serial.print(' ');
    serialPrint2Digit(currentRtc.hour);
    Serial.print(':');
    serialPrint2Digit(currentRtc.minute);
    Serial.print(':');
    serialPrint2Digit(currentRtc.second);

    Serial.print(F(" | air="));
    serialPrintTemp10(lastSensor.airTemp10);
    Serial.print(F("C hum="));
    serialPrintHumidity2(lastSensor.humidity2);
    Serial.print(F("% floor="));
    serialPrintTemp10(lastSensor.floorTemp10);
    Serial.print(F("C cdsRaw="));
    Serial.print(lastSensor.cdsValue);
    Serial.print(F(" ir="));
    Serial.print(lastSensor.irValue);
    Serial.print(F(" valid="));
    Serial.print(lastSensor.valid ? 1 : 0);

    Serial.print(F(" | sale A="));
    Serial.print(current_hour_menuA);
    Serial.print(F(" B="));
    Serial.print(current_hour_menuB);
    Serial.print(F(" C="));
    Serial.print(current_hour_menuC);

    Serial.print(F(" | kiosk A="));
    Serial.print(kioskTempMenuA);
    Serial.print(F(" B="));
    Serial.print(kioskTempMenuB);
    Serial.print(F(" C="));
    Serial.print(kioskTempMenuC);

    Serial.print(F(" | accSamples="));
    Serial.print(hourAcc.sampleCount);
    Serial.print(F(" file="));
    Serial.println(hourAcc.activeFileName);
}


static void enterInitGenerateState(void);

static bool refreshStorageNow(bool showStatus) {
    bool ok = storageRefresh();
    if (ok) {
        if (!storageReady && showStatus) {
            showOwnerMessage(F("SD READY"), F("CACHE OK"));
            blinkGreenOnce();
        }
        storageReady = true;
        storageClearAccessError();
        return true;
    }

    if (storageReady && showStatus) {
        showOwnerMessage(F("SD ERROR"), F("CHECK CARD"));
        setLedError();
    }
    storageReady = false;
    return false;
}

static bool storageReadyQuickCheck(void) {
    storageClearAccessError();
    if (!storageReady) {
        return false;
    }

    if (storageQuickCheck()) {
        return true;
    }

    storageReady = false;
    storageMarkAccessError();
    return false;
}

static bool handleStorageAccessFailureAfterOperation(bool initCollectContext) {
    if (!storageHadAccessError()) {
        return false;
    }

    if (!storageQuickCheck()) {
        storageReady = false;
        if (initCollectContext) {
            showInitCollectSdMissingTemp();
        } else {
            enterSdMissingState();
        }
        return true;
    }

    storageClearAccessError();
    return false;
}

static void handleStorageRefreshPeriodic(void) {
    /*
       SD is not polled periodically anymore.
       Normal SD missing recovery is handled only by D key in STATE_SD_MISSING,
       and INIT_COLLECT SD checks are handled only by D short or hourly save.
    */
}

static void enterSdMissingState(void) {
    storageReady = false;
    currentState = STATE_SD_MISSING;
    setLedError();
    showOwnerMessage(F("SD MISSING"), F("D TO RETRY"));
}

static bool ensureStorageNormal(void) {
    if (storageReadyQuickCheck()) return true;
    enterSdMissingState();
    return false;
}

static bool retryStorageFromSdMissingState(void) {
    showOwnerMessage(F("SD RETRY"), F("PLEASE WAIT"));
    setLedInput();
    Serial.println(F("SD retry requested from SD_MISSING state"));

    bool ok = refreshStorageNow(false);
    if (ok) {
        Serial.println(F("SD retry success"));
        showOwnerMessage(F("SD READY"), F("RETURNING"));
        blinkGreenOnce();
        delay(700);
        enterMonitoringState();
        retryPendingAutoSaves(true);
        return true;
    }

    Serial.println(F("SD retry failed"));
    setLedError();
    blinkRedOnce();
    showOwnerMessage(F("SD MISSING"), F("D TO RETRY"));
    return false;
}

static void showInitCollectSdMissingTemp(void) {
    storageReady = false;
    setLedError();
    showOwnerMessage(F("SD MISSING"), F("CHECK CARD"));
    delay(2000);
    setLedInput();
    showInitCollectProgressNow();
}

static bool appendResetCollectFromAccumulator(const HourlyAccumulator* acc,
                                             uint8_t menuA,
                                             uint8_t menuB,
                                             uint8_t menuC) {
    if (acc == NULL) return false;
    if (acc->sampleCount < MIN_SENSOR_SAMPLES_PER_HOUR) return false;

    SalesRecord record;
    record.yearOffset = acc->yearOffset;
    record.month = acc->month;
    record.day = acc->day;
    record.hour = acc->hour;
    record.airTemp10 = (int16_t)(acc->airSum / (int32_t)acc->sampleCount);
    record.humidity2 = (uint8_t)(acc->humSum / acc->sampleCount);
    record.floorTemp10 = (int16_t)(acc->floorSum / (int32_t)acc->sampleCount);
    record.cdsValue = (uint16_t)(acc->cdsSum / acc->sampleCount);
    record.irValue = (uint16_t)(acc->irSum / acc->sampleCount);
    record.menuA = menuA;
    record.menuB = menuB;
    record.menuC = menuC;

    return appendResetCollectRecord(&record);
}

static bool handleInitCollectSdCheck(void) {
    if (currentState != STATE_INIT_COLLECT) return false;

    showOwnerMessage(F("SD CHECKING"), F("PLEASE WAIT"));
    setLedInput();

    if (!refreshStorageNow(false)) {
        showInitCollectSdMissingTemp();
        return false;
    }

    uint16_t count = countResetCollectRecords();
    if (count >= INIT_COLLECT_HOURS_TOTAL) {
        if (!tryImportExternalInitData(&initStatus)) {
            showOwnerMessage(F("RESET DATA ERR"), F("CHECK FILE"));
            setLedError();
            delay(2000);
            setLedInput();
            showInitCollectProgressNow();
            return false;
        }

        showOwnerMessage(F("72H DATA OK"), F("MAKE INIT"));
        blinkGreenOnce();
        delay(500);
        enterInitGenerateState();
        return true;
    }

    char l1[17];
    char l2[17];
    uint16_t shown = count;
    if (shown > INIT_COLLECT_HOURS_TOTAL) shown = INIT_COLLECT_HOURS_TOTAL;
    snprintf_P(l1, sizeof(l1), PSTR("RESET %02u/%02u"), (unsigned)shown, (unsigned)INIT_COLLECT_HOURS_TOTAL);
    snprintf_P(l2, sizeof(l2), PSTR("NEED %02u MORE"), (unsigned)(INIT_COLLECT_HOURS_TOTAL - shown));
    showOwnerText(l1, l2);
    delay(1500);
    showInitCollectProgressNow();
    return false;
}

static void runRealtimeTasks(bool allowKiosk) {
    handleStorageRefreshPeriodic();

    if (updateCurrentRtc()) {
        handleHourRollover(&currentRtc);
    }

    handleLiveSensorRefresh();
    handleSensorSampling();

    if (currentState == STATE_MONITORING && storageReady) {
        retryPendingAutoSaves(false);
    }

    if (allowKiosk) {
        handleKioskInput();
    }

    printDebugStatusToSerial();
}

static void runInitGenerateForegroundTasks(void) {
    /*
       During 1-year generation, do not read sensors, do not process kiosk
       sales, and do not run ordinary hourly auto-save.  Keep only the RTC
       updated so the system can return to monitoring with a valid clock.
       D-long cancel is handled separately by handleOwnerKeyEvent().
    */
    updateCurrentRtc();
}

static void resyncRealtimeAfterInitGeneration(void) {
    resetCurrentHourSalesAndKiosk();
    autoSaveHolidayFlag = isHolidayDate(currentRtc.yearOffset, currentRtc.month, currentRtc.day) ? 1 : 0;
    beginNewHourlyAccumulator(&currentRtc);
    lastSensorSampleMs = 0;
    lastLiveSensorReadMs = 0;
}

static void enterMonitoringState(void) {
    currentState = STATE_MONITORING;
    setLedMonitoring();
    resetPredictInput();
    resetManualInput();
    resetHolidayInput();
    resetResetInput();
    lastOwnerLcdMs = 0;
    showOwnerSales(currentRtc.hour, currentRtc.minute, current_hour_menuA, current_hour_menuB, current_hour_menuC);
}

static void enterPredictState(void) {
    currentState = STATE_PREDICT_INPUT;
    setLedInput();
    resetPredictInput();
    showOwnerMessage(F("PREDICT MODE"), F("MENU?"));
}

static void enterManualState(void) {
    currentState = STATE_MANUAL_INPUT;
    setLedInput();
    resetManualInput();
    showOwnerMessage(F("ADD SALE"), F("MENU?"));
}

static void enterHolidayState(void) {
    currentState = STATE_HOLIDAY_INPUT;
    setLedInput();
    resetHolidayInput();
    showOwnerMessage(F("Holiday?"), F("YES(A) / NO(B)"));
}

static void enterResetConfirmState(void) {
    if (currentState == STATE_INIT_COLLECT || currentState == STATE_INIT_GENERATE) return;
    currentState = STATE_RESET_CONFIRM;
    setLedInput();
    resetResetInput();
    showResetConfirm();
}

static void cancelInitCollectKeepData(void) {
    if (currentState != STATE_INIT_COLLECT) return;

    initStatus.phase = 0;
    initStatus.collectHoursDone = 0;
    initStatus.generateIndex = 0;
    initStatus.totalGenerateCount = INIT_GENERATE_RECORDS_TOTAL;
    initStatus.isComplete = 0;
    initStatus.version = 1;
    initStatus.reserved[0] = 0;
    initStatus.reserved[1] = 0;
    initStatus.reserved[2] = 0;

    saveInitStatus(&initStatus);
    initGenerationResetRuntime();

    currentState = STATE_MONITORING;
    setLedMonitoring();
    showOwnerMessage(F("INIT CANCEL"), F("DATA KEPT"));
}


static void requestInitGenerateCancel(void) {
    if (currentState != STATE_INIT_GENERATE) return;
    if (initGenerateCancelRequested) return;

    initGenerateCancelRequested = true;
    setLedInput();
    showOwnerMessage(F("GEN CANCEL"), F("FINISHING"));
    Serial.println(F("Init generation cancel requested"));
}

static void finishInitGenerateCancel(void) {
    if (currentState != STATE_INIT_GENERATE) return;

    /*
       The generator writes one SalesRecord at a time and closes the file before
       returning from generateNextInitRecord().  Therefore this function is called
       only after the last in-progress record/file append has already completed.
       Keep generated W/H records, remove disposable RESET/INIT72.BIN, and prevent
       automatic resume on the next boot by clearing phase.
    */
    initStatus.phase = 0;
    initStatus.isComplete = 0;
    initStatus.totalGenerateCount = INIT_GENERATE_RECORDS_TOTAL;
    initStatus.version = 1;
    initStatus.reserved[1] = 0;
    initStatus.reserved[2] = 0;

    bool statOk = saveInitStatus(&initStatus);
    bool resetOk = clearResetCollectData();
    initGenerationResetRuntime();
    initGenerateCancelRequested = false;

    if (!statOk || !resetOk) {
        showOwnerMessage(F("CANCEL WARN"), F("CHECK SD"));
        setLedError();
        delay(1200);
    } else {
        showOwnerMessage(F("GEN STOPPED"), F("DATA KEPT"));
        blinkBlueOnce();
        delay(1200);
    }

    resyncRealtimeAfterInitGeneration();
    enterMonitoringState();
}

static void enterInitCollectState(void) {
    DateTimeParts now;
    if (!readRtcDateTime(&now)) {
        showOwnerMessage(F("RTC ERROR"), F("CHECK LINE"));
        setLedError();
        return;
    }

    currentRtc = now;
    rtcReadOk = true;
    lastSoftwareClockMs = millis();

    if (!refreshStorageNow(false) || !resetCollectBegin()) {
        enterSdMissingState();
        return;
    }

    currentState = STATE_INIT_COLLECT;
    initGenerateCancelRequested = false;
    setLedInput();

    autoSaveHolidayFlag = isHolidayDate(now.yearOffset, now.month, now.day) ? 1 : 0;
    resetCurrentHourSalesAndKiosk();
    beginNewHourlyAccumulator(&now);
    lastSensorSampleMs = 0;

    beginInitCollectFromReset(&initStatus, &now);

    if (now.minute != 0 || now.second != 0) {
        /*
           첫 부분 시간대가 72개 데이터에 섞이지 않도록 다음 정각까지 대기한다.
           reserved[1] == 1은 재부팅 후에도 '첫 정각 대기 중'임을 알리는 플래그다.
        */
        initStatus.reserved[1] = 1;
        if (!saveInitStatus(&initStatus)) {
            showOwnerMessage(F("STAT ERROR"), F("INITSTAT"));
            setLedError();
            return;
        }
    }

    lastOwnerLcdMs = 0;
    showInitCollectProgressNow();
}

static void enterInitGenerateState(void) {
    currentState = STATE_INIT_GENERATE;
    initGenerateCancelRequested = false;
    setLedInput();
    if (!refreshStorageNow(false)) {
        enterSdMissingState();
        return;
    }
    if (!prepareInitGeneration(&initStatus)) {
        showOwnerMessage(F("INIT ERROR"), F("CHECK SD"));
        setLedError();
        currentState = STATE_INIT_COLLECT;
        return;
    }
    showInitMake(initStatus.generateIndex, INIT_GENERATE_RECORDS_TOTAL);
}

static void handlePredictNormalKey(char key) {
    if (predStage == PRED_STAGE_MENU) {
        if (key == 'A' || key == 'B' || key == 'C') {
            predMenu = key;
            predStage = PRED_STAGE_DATE;
            clearInputBuffer();
            showOwnerMessage(F("DATE:"), F("YYYYMMDD"));
            return;
        }
        if (key == '*') {
            resetPredictInput();
            showOwnerMessage(F("PREDICT MODE"), F("MENU?"));
            return;
        }
        if (key == '#') {
            showOwnerMessage(F("SELECT MENU"), F("A/B/C"));
            return;
        }
        return;
    }

    if (key == 'A' || key == 'B' || key == 'C') {
        return;
    }

    if (key == '*') {
        clearInputBuffer();
    } else if (key >= '0' && key <= '9') {
        uint8_t maxLen = (predStage == PRED_STAGE_DATE) ? 8 : 2;
        appendDigitToInput(key, maxLen);
    } else if (key == '#') {
        if (predStage == PRED_STAGE_DATE) {
            if (inputLen != 8) {
                showOwnerMessage(F("DATE ERROR"), F("YYYYMMDD"));
                clearInputBuffer();
                return;
            }

            uint16_t y = (uint16_t)(inputBuffer[0] - '0') * 1000U +
                         (uint16_t)(inputBuffer[1] - '0') * 100U +
                         (uint16_t)(inputBuffer[2] - '0') * 10U +
                         (uint16_t)(inputBuffer[3] - '0');
            uint8_t m = (uint8_t)((inputBuffer[4] - '0') * 10 + (inputBuffer[5] - '0'));
            uint8_t d = (uint8_t)((inputBuffer[6] - '0') * 10 + (inputBuffer[7] - '0'));

            if (y < 2000 || y > 2255 || m < 1 || m > 12 || d < 1 || d > daysInMonth((uint8_t)(y - 2000), m)) {
                showOwnerMessage(F("DATE ERROR"), F("TRY AGAIN"));
                clearInputBuffer();
                return;
            }

            predYearOffset = (uint8_t)(y - 2000);
            predMonth = m;
            predDay = d;
            predStage = PRED_STAGE_START;
            clearInputBuffer();
            showOwnerMessage(F("START_TIME:"), F("0-23"));
            return;
        }

        if (predStage == PRED_STAGE_START) {
            uint16_t h = parseInputU16();
            if (inputLen == 0 || h > 23) {
                showOwnerMessage(F("TIME ERROR"), F("0-23"));
                clearInputBuffer();
                return;
            }
            predStartHour = (uint8_t)h;
            predStage = PRED_STAGE_END;
            clearInputBuffer();
            showOwnerMessage(F("END_TIME:"), F("1-24"));
            return;
        }

        if (predStage == PRED_STAGE_END) {
            uint16_t h = parseInputU16();
            if (inputLen == 0 || h > 24) {
                showOwnerMessage(F("TIME ERROR"), F("1-24"));
                clearInputBuffer();
                return;
            }

            predEndHour = (uint8_t)h;
            if (predStartHour >= predEndHour) {
                showOwnerMessage(F("RANGE ERROR"), F("S < E ONLY"));
                clearInputBuffer();
                return;
            }

            PredictionContext ctx;
            ctx.yearOffset = predYearOffset;
            ctx.month = predMonth;
            ctx.day = predDay;
            ctx.hour = predStartHour;
            ctx.dayOfWeek = getDayOfWeek(predYearOffset, predMonth, predDay);
            ctx.isHoliday = isHolidayDate(predYearOffset, predMonth, predDay) ? 1 : 0;
            ctx.airTemp10 = lastSensor.airTemp10;
            ctx.humidity2 = lastSensor.humidity2;
            ctx.floorTemp10 = lastSensor.floorTemp10;
            ctx.cdsValue = lastSensor.cdsValue;
            ctx.irValue = lastSensor.irValue;
            ctx.mode = PREDICT_FUTURE_CURRENT_ENV;

            uint16_t a = 0, b = 0, c = 0;
            uint8_t conf = CONF_NONE;
            uint8_t used = 0;
            uint8_t maxStage = 0;
            bool ok = false;
            showOwnerMessage(F("LOADING"), F("PLEASE WAIT"));
            setLedInput();
            if (ensureStorageNormal()) {
                storageClearAccessError();
                ok = executePredictRange(&ctx, predStartHour, predEndHour, &a, &b, &c, &conf, &used, &maxStage);
            }
            if (currentState == STATE_SD_MISSING) return;
            if (handleStorageAccessFailureAfterOperation(false)) return;

            if (!ok) {
                showOwnerMessage(F("DATA LOW"), F("NEED RECORD"));
                setLedError();
            } else {
                uint16_t selected = 0;
                if (predMenu == 'A') selected = a;
                else if (predMenu == 'B') selected = b;
                else selected = c;

                char l1[17];
                char l2[17];
                if (selected > 999U) selected = 999U;
                if (conf > CONF_HIGH) conf = CONF_NONE;
                snprintf_P(l1, sizeof(l1), PSTR("PRED %c RESULT"), predMenu);
                snprintf_P(l2, sizeof(l2), PSTR("%c:%03u CF%1u USE%03u"),
                           predMenu,
                           (unsigned)selected,
                           (unsigned)conf,
                           (unsigned)used);
                showOwnerText(l1, l2);

                Serial.print(F("MENU:"));
                Serial.print(predMenu);
                Serial.print(F(" A:"));
                Serial.print(a);
                Serial.print(F(" B:"));
                Serial.print(b);
                Serial.print(F(" C:"));
                Serial.print(c);
                Serial.print(F(" CONF:"));
                Serial.print(conf);
                Serial.print(F(" USED:"));
                Serial.print(used);
                Serial.print(F(" STAGE:"));
                Serial.print(maxStage);
                Serial.print(F(" INIT:"));
                Serial.println(maxStage == 6 ? 1 : 0);
            }
            clearInputBuffer();
            return;
        }
    } else {
        return;
    }

    char l2[17];
    snprintf_P(l2, sizeof(l2), PSTR("%s"), inputBuffer);
    if (predStage == PRED_STAGE_DATE) showOwnerText("DATE:", l2);
    else if (predStage == PRED_STAGE_START) showOwnerText("START_TIME:", l2);
    else showOwnerText("END_TIME:", l2);
}

static void handleManualNormalKey(char key) {
    if (key == 'A' || key == 'B' || key == 'C') {
        manualMenu = key;
        clearInputBuffer();
        showOwnerMessage(F("ADD SALE"), F("SALE?"));
        return;
    }

    if (key == '*') {
        clearInputBuffer();
        manualCount = 0;
        showOwnerMessage(F("ADD SALE"), manualMenu ? F("SALE?") : F("MENU?"));
        return;
    }

    if (key >= '0' && key <= '9') {
        appendDigitToInput(key, 3);
        char l2[17];
        snprintf_P(l2, sizeof(l2), PSTR("%s"), inputBuffer);
        showOwnerText("SALE?", l2);
        return;
    }

    if (key == '#') {
        if (manualMenu == 0 || inputLen == 0) {
            showOwnerMessage(F("INPUT ERROR"), F("MENU/SALE"));
            return;
        }

        uint16_t count = parseInputU16();
        if (count > 255U) count = 255U;
        manualCount = (uint8_t)count;

        SalesRecord rec;
        rec.yearOffset = hourAcc.yearOffset;
        rec.month = hourAcc.month;
        rec.day = hourAcc.day;
        rec.hour = hourAcc.hour;
        rec.airTemp10 = lastSensor.airTemp10;
        rec.humidity2 = lastSensor.humidity2;
        rec.floorTemp10 = lastSensor.floorTemp10;
        rec.cdsValue = lastSensor.cdsValue;
        rec.irValue = lastSensor.irValue;
        rec.menuA = current_hour_menuA;
        rec.menuB = current_hour_menuB;
        rec.menuC = current_hour_menuC;

        bool ok = false;
        if (ensureStorageNormal()) {
            storageClearAccessError();
            ok = executeManualSave((uint8_t)manualMenu,
                                   manualCount,
                                   &rec,
                                   hourAcc.activeFileName,
                                   hourAcc.activeIsHoliday,
                                   hourAcc.activeTempZone,
                                   hourAcc.activeLightZone);
        }
        if (currentState == STATE_SD_MISSING) return;
        if (handleStorageAccessFailureAfterOperation(false)) return;

        if (ok) {
            if (manualMenu == 'A') current_hour_menuA = satAddU8(current_hour_menuA, manualCount);
            else if (manualMenu == 'B') current_hour_menuB = satAddU8(current_hour_menuB, manualCount);
            else if (manualMenu == 'C') current_hour_menuC = satAddU8(current_hour_menuC, manualCount);
            blinkGreenOnce();
            resetManualInput();
            currentState = STATE_MONITORING;
            setLedMonitoring();
            lastOwnerLcdMs = 0;
            showOwnerSales(currentRtc.hour, currentRtc.minute, current_hour_menuA, current_hour_menuB, current_hour_menuC);
            return;
        } else {
            showOwnerMessage(F("SD ERROR"), F("WRITE FAIL"));
            setLedError();
        }
        resetManualInput();
    }
}

static void handleHolidayNormalKey(char key) {
    if (key == 'A') {
        pendingHolidayInput = 1;
        showOwnerMessage(F("Holiday YES"), F("# TO SAVE"));
    } else if (key == 'B') {
        pendingHolidayInput = 0;
        showOwnerMessage(F("Holiday NO"), F("# TO SAVE"));
    } else if (key == '*') {
        pendingHolidayInput = HOLIDAY_INPUT_NONE;
        showOwnerMessage(F("Holiday?"), F("YES(A) / NO(B)"));
    } else if (key == '#') {
        if (pendingHolidayInput == HOLIDAY_INPUT_NONE) {
            showOwnerMessage(F("SELECT"), F("A OR B"));
            return;
        }
        applyHolidayFlagToCurrentAccumulator(pendingHolidayInput);
        showOwnerMessage(F("SAVED"), F("Holiday UPDATED"));
        blinkGreenOnce();
    }
}

static void handleResetConfirmNormalKey(char key) {
    if (key == 'A') {
        pendingResetInput = 1;
        showOwnerMessage(F("RESET YES"), F("# TO START"));
    } else if (key == 'B') {
        pendingResetInput = 0;
        showOwnerMessage(F("RESET NO"), F("# TO CANCEL"));
    } else if (key == '*') {
        pendingResetInput = RESET_INPUT_NONE;
        showResetConfirm();
    } else if (key == '#') {
        if (pendingResetInput == RESET_INPUT_NONE) {
            showOwnerMessage(F("SELECT"), F("A OR B"));
            return;
        }

        if (pendingResetInput == 0) {
            enterMonitoringState();
            return;
        }

        showOwnerMessage(F("RESETTING"), F("WAIT"));
        storageClearAccessError();

        /*
           A confirmed RESET means the user wants to discard current runtime
           sales context.  Pending auto-save entries from before the reset must
           not be retried later, otherwise old real records can be written back
           after W/H files were cleared.
        */
        clearPendingAutoSaves();

        if (!ensureStorageNormal()) {
            return;
        }

        if (!resetSalesDataOnly()) {
            if (handleStorageAccessFailureAfterOperation(false)) {
                return;
            }
            showOwnerMessage(F("RESET WARN"), F("FILES LEFT"));
            setLedError();
            delay(1500);
            showResetConfirm();
            return;
        }

        initGenerationResetRuntime();
        enterInitCollectState();
    }
}

static void handleOwnerKeyEvent(void) {
    OwnerKeyEvent ev = readOwnerKeyEvent();
    if (ev.type == OWNER_KEY_NONE) return;

    if (ev.type == OWNER_KEY_D_LONG) {
        if (currentState == STATE_INIT_COLLECT) {
            cancelInitCollectKeepData();
        } else if (currentState == STATE_INIT_GENERATE) {
            requestInitGenerateCancel();
        } else if (currentState == STATE_SD_MISSING) {
            retryStorageFromSdMissingState();
        } else {
            enterResetConfirmState();
        }
        return;
    }

    if (ev.type == OWNER_KEY_D_SHORT) {
        if (currentState == STATE_SD_MISSING) {
            retryStorageFromSdMissingState();
        } else if (currentState == STATE_INIT_COLLECT) {
            handleInitCollectSdCheck();
        } else if (currentState == STATE_MONITORING) enterPredictState();
        else if (currentState == STATE_PREDICT_INPUT) enterManualState();
        else if (currentState == STATE_MANUAL_INPUT) enterHolidayState();
        else if (currentState == STATE_HOLIDAY_INPUT) enterMonitoringState();
        else if (currentState == STATE_RESET_CONFIRM) enterMonitoringState();
        return;
    }

    if (ev.type != OWNER_KEY_NORMAL) return;

    if (currentState == STATE_PREDICT_INPUT) handlePredictNormalKey(ev.key);
    else if (currentState == STATE_MANUAL_INPUT) handleManualNormalKey(ev.key);
    else if (currentState == STATE_HOLIDAY_INPUT) handleHolidayNormalKey(ev.key);
    else if (currentState == STATE_RESET_CONFIRM) handleResetConfirmNormalKey(ev.key);
}

static void updateOwnerMonitoringLcd(void) {
    uint32_t nowMs = millis();
    if ((nowMs - lastOwnerLcdMs) < 1000UL) return;
    lastOwnerLcdMs = nowMs;

    if (currentState == STATE_MONITORING) {
        showOwnerSales(currentRtc.hour, currentRtc.minute, current_hour_menuA, current_hour_menuB, current_hour_menuC);
    } else if (currentState == STATE_INIT_COLLECT) {
        showInitCollectProgressNow();
    } else if (currentState == STATE_INIT_GENERATE) {
        showInitMake(initStatus.generateIndex, INIT_GENERATE_RECORDS_TOTAL);
    }
}

static void updateKioskLcdPeriodic(void) {
    uint32_t nowMs = millis();
    if ((nowMs - lastKioskLcdMs) < 1500UL) return;
    lastKioskLcdMs = nowMs;
    showKioskOrder(kioskTempMenuA, kioskTempMenuB, kioskTempMenuC);
}

void setup() {
    Serial.begin(9600);
    hardwareBegin();

    storageReady = storageBegin();
    if (!storageReady) {
        enterSdMissingState();
    }

    SensorSnapshot s;
    if (readSensors(&s)) {
        lastSensor = s;
        lastLiveSensorReadMs = millis();
    }

#if RTC_SET_TIME_ON_UPLOAD
    setSoftwareClockFromUploadConfig();
#endif

    if (readRtcDateTime(&currentRtc)) {
        rtcReadOk = true;
        Serial.println(F("RTC READ OK"));
    } else {
        rtcReadOk = false;
#if RTC_SET_TIME_ON_UPLOAD
        setSoftwareClockFromUploadConfig();
        Serial.println(F("RTC READ FAIL - SW CLOCK STARTS FROM RTC_SET_* VALUES"));
#else
        Serial.println(F("RTC READ FAIL - SW CLOCK STARTS FROM DEFAULT 2026-01-01 00:00"));
#endif
        showOwnerMessage(F("RTC ERROR"), F("SW CLOCK"));
    }
    lastSoftwareClockMs = millis();
    autoSaveHolidayFlag = isHolidayDate(currentRtc.yearOffset, currentRtc.month, currentRtc.day) ? 1 : 0;
    beginNewHourlyAccumulator(&currentRtc);

    InitStatusRecord st;
    if (storageReady && loadInitStatus(&st)) {
        initStatus = st;
        if (initStatus.phase == 1) {
            currentState = STATE_INIT_COLLECT;
        } else if (initStatus.phase == 2) {
            if (initStatus.generateIndex > INIT_GENERATE_RECORDS_TOTAL) {
                initStatus.generateIndex = INIT_GENERATE_RECORDS_TOTAL;
            }
            currentState = STATE_INIT_GENERATE;
            prepareInitGeneration(&initStatus);
        } else {
            currentState = STATE_MONITORING;
        }
    }

    if (!storageReady) {
        enterSdMissingState();
    }

    showKioskOrder(0, 0, 0);
}

void loop() {
    if (currentState == STATE_INIT_GENERATE) {
        runInitGenerateForegroundTasks();
        handleOwnerKeyEvent();

        if (initGenerateCancelRequested) {
            finishInitGenerateCancel();
            return;
        }

        storageClearAccessError();
        bool ok = generateNextInitRecord(&initStatus);
        if (!ok) {
            if (handleStorageAccessFailureAfterOperation(false)) {
                return;
            }
            showOwnerMessage(F("INIT ERROR"), F("CHECK SD"));
            setLedError();
            delay(100);
            return;
        }

        if (initGenerateCancelRequested) {
            finishInitGenerateCancel();
            return;
        }

        if (isInitGenerationComplete(&initStatus)) {
            showInitDone();
            bool resetCleared = clearResetCollectData();
            if (!resetCleared) {
                if (handleStorageAccessFailureAfterOperation(false)) {
                    return;
                }
                showOwnerMessage(F("INIT WARN"), F("RESET FILE"));
                setLedError();
                delay(1200);
            } else {
                initGenerateCancelRequested = false;
                delay(1200);
            }
            resyncRealtimeAfterInitGeneration();
            enterMonitoringState();
            return;
        }

        updateOwnerMonitoringLcd();
        return;
    }

    if (currentState == STATE_SD_MISSING) {
        updateCurrentRtc();
        handleOwnerKeyEvent();
        return;
    }

    runRealtimeTasks(true);
    handleOwnerKeyEvent();

    if (currentState == STATE_INIT_COLLECT) {
        if (initStatus.collectHoursDone >= INIT_COLLECT_HOURS_TOTAL || initStatus.phase == 2) {
            enterInitGenerateState();
            return;
        }
    }

    updateOwnerMonitoringLcd();
    updateKioskLcdPeriodic();
}
