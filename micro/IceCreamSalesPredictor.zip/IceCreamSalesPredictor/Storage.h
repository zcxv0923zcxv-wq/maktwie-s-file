#ifndef STORAGE_H
#define STORAGE_H

#include <Arduino.h>
#include <SD.h>
#include "Types.h"

bool storageBegin(void);
bool storageRefresh(void);
bool storageQuickCheck(void);
void storageClearAccessError(void);
void storageMarkAccessError(void);
bool storageHadAccessError(void);

void clearFileCache(void);
void rebuildFileCache(void);
bool isFileCacheBitSet(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone);
void setFileCacheBit(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone);
void clearFileCacheBit(uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone);

void buildSalesFileName(char* fileName, size_t fileNameSize, uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone);
bool overwriteRecordAt(File* file, uint32_t pos, const SalesRecord* record);
bool upsertLatestRecord(const char* fileName, const SalesRecord* record,
                        uint8_t isHoliday, uint8_t hour, uint8_t tempZone, uint8_t lightZone);
bool saveGeneratedInitRecordToSalesFile(const SalesRecord* record,
                                        uint8_t isHoliday,
                                        uint8_t tempZone,
                                        uint8_t lightZone);
bool executeAutoSaveFromAccumulator(const HourlyAccumulator* acc, uint8_t menuA, uint8_t menuB, uint8_t menuC);
bool executeManualSave(uint8_t menuType, uint8_t saleCount,
                       const SalesRecord* timestampRecord,
                       const char* preferredFileName,
                       uint8_t isHoliday, uint8_t tempZone, uint8_t lightZone);

bool resetSalesDataOnly(void);

bool resetCollectBegin(void);
bool appendResetCollectRecord(const SalesRecord* record);
uint16_t countResetCollectRecords(void);
bool readResetCollectRecordAt(uint16_t index, SalesRecord* out);
bool clearResetCollectData(void);

bool appendInitRecord(const SalesRecord* record);
bool saveInitStatus(const InitStatusRecord* st);
bool loadInitStatus(InitStatusRecord* st);
bool isInitStatusValid(const InitStatusRecord* st);
uint16_t recoverGenerateIndexFromInitRecordFile(void);
bool isInitFallbackAvailable(void);

bool readInitRecordAt(uint16_t recordIndex, SalesRecord* out);

bool readWeightHeader(WeightHeader* header);
bool readWeightRecordByIndex(uint16_t index, WeightRecord* out);
bool readWeightRecordByTargetDate(uint8_t yearOffset, uint8_t month, uint8_t day, uint8_t hour, WeightRecord* out);
bool isWeightHeaderValid(const WeightHeader* header);
bool isWeightRecordValid(const WeightRecord* record);

#endif
