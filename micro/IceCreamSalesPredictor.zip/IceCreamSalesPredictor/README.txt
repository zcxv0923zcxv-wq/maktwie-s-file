IceCreamSalesPredictor lazy-refresh and fast-upsert fix

Purpose
- Reduce delay in prediction mode and hourly auto-save without changing prediction search logic or accuracy.
- Remove full SD/file-cache rebuild from normal prediction/manual/auto-save paths.
- Keep duplicate timestamp protection after 1-year generated data exists.
- Do not add a time-index file.

1. Lazy SD refresh / quick SD check
Previous behavior
- Some normal paths called storageRefresh() before SD-dependent work.
- storageRefresh() calls SD.begin() and rebuildFileCache().
- rebuildFileCache() checks all possible W/H condition files:
  2 holiday flags * 24 hours * 4 temp zones * 3 light zones = 576 SD.exists() checks.

New behavior
- Full storageRefresh() is kept for boot, SD_MISSING retry, and explicit INIT_COLLECT SD check.
- Prediction, manual save, and ordinary hourly auto-save no longer rebuild the full cache before working.
- They call storageQuickCheck(), which only opens the SD root directory to verify card access.
- If SD.open()/SD.read()/SD.write() fails during an operation, Storage.cpp marks a storage access error.
- After an operation failure, the main sketch calls storageQuickCheck():
  * quick check fails -> STATE_SD_MISSING
  * quick check succeeds -> treat as file/write/data issue, not card removal

D-key behavior
- No new D-key refresh command was added.
- D still retries only in STATE_SD_MISSING.
- D short in INIT_COLLECT still performs the existing explicit SD/RESET/INIT72.BIN check.

2. Faster duplicate timestamp removal
Previous behavior
- upsertLatestRecord() called removeTimestampFromAllConditionFiles().
- Each existing condition file for the same hour could be rewritten through TMPREC.BIN even when the target timestamp was not present.
- After 1-year generation, many files exist for the same hour, so one auto-save could rewrite many files unnecessarily.

New behavior
- removeTimestampFromAllConditionFiles() now uses a two-step method:
  1) Read-only scan each possible condition file for the same hour.
  2) Rewrite only the file(s) where the same timestamp is actually found.
- Duplicate timestamp protection is preserved.
- Existing generated records are still replaced by real auto/manual records.
- Files without the timestamp are no longer copied/deleted/restored.

Expected speed impact
- Prediction: avoids 576-file cache rebuild before normal prediction.
- Auto-save: avoids 576-file cache rebuild and avoids rewriting condition files that do not contain the timestamp.
- Accuracy impact: none intended. Candidate search stages, K_NEIGHBORS, distance scoring, CF rules, and prediction averaging are unchanged.

Important behavior
- If the SD card is removed before prediction/manual save/auto-save, storageQuickCheck() should detect it and enter SD MISSING.
- If the SD card is removed during a read/write, the failed SD operation marks an access error and the main sketch confirms it using storageQuickCheck().
- If a cached file is missing but the SD card itself is healthy, Prediction.cpp clears that file's cache bit and continues.

Validation
- Stub-based C++ syntax check passed for IceCreamSalesPredictor.ino, Storage.cpp, Prediction.cpp, InitGeneration.cpp, Utils.cpp, and HardwareIO.cpp.
- Actual Arduino MEGA upload was not performed in this environment.

Code/algorithm conflict audit fix
- Prediction no longer calls SD.exists() for cache-miss candidate files.
- Prediction now relies on fileCache built at boot and updated by writes/deletes.
- If a cached file fails to open/read, the storage access error flag is set and the main sketch verifies card presence with storageQuickCheck().
- STATE_INIT_GENERATE now calls runRealtimeTasks(false), so kiosk order input is blocked during 1-year generation.
- Hour rollover during STATE_INIT_GENERATE no longer performs ordinary auto-save.  It only realigns the hourly accumulator to the current time.
- This prevents generated W/H file creation and real hourly save/upsert from interleaving during initial generation.

Init generation realtime-pause fix
- During STATE_INIT_GENERATE, the main loop now calls runInitGenerateForegroundTasks() instead of runRealtimeTasks(false).
- This generation-only foreground path updates only the RTC clock.
- It does not read live sensors, does not accumulate hourly sensor samples, does not process kiosk menu/confirm buttons, and does not run ordinary hourly auto-save.
- D-long cancel remains available through handleOwnerKeyEvent().
- Owner LCD progress display remains available through showInitMake().
- Kiosk LCD periodic refresh is skipped during generation to reduce unnecessary work.
- After generation completes or is cancelled, resyncRealtimeAfterInitGeneration() clears temporary sales, recalculates the holiday flag, and starts a fresh hourly accumulator from the current RTC time before returning to monitoring.

Code/algorithm conflict audit fix 2
- STATE_INIT_GENERATE now checks initGenerateCancelRequested immediately after reading the D-long key event.
- If D-long is detected between generation units, the system stops without writing one extra generated record.
- The completion path now checks clearResetCollectData(); if RESET/INIT72.BIN removal fails, the code either enters SD_MISSING or shows INIT WARN / RESET FILE instead of silently returning to monitoring.
- Fast upsert now skips condition files whose fileCache bit is clear before calling SD.exists()/SD.open().
- This preserves duplicate timestamp protection for cached/generated files while avoiding unnecessary SD probes for absent T/L files.
- No time-index file was added.


Prediction-only conflict fix (fallback excluded)
- INITREC.BIN fallback logic was intentionally left unchanged.
- Stage 3 real-data candidate scanning no longer re-scans the same adjacent temp/light files already scanned in Stage 2. This prevents duplicated SD reads and avoids consuming MAX_SCAN_RECORDS before wider-condition files are reached.
- Range prediction now treats closed hours as deterministic zero-sales hours instead of DATA LOW. Closed hours are skipped during candidate search and do not reduce confidence for open hours in the same requested range.
- A range containing only closed hours returns a visible zero prediction instead of DATA LOW.

Auto-save conflict audit and pending-save fix
- Ordinary hourly auto-save no longer loses the completed hour immediately when the write cannot be completed.
- At hour rollover, an open-hour record is first copied into a small pending auto-save queue before any SD write is attempted.
- If the SD card is missing at rollover, the completed hour remains pending and is retried after SD_MISSING recovery.
- If there is no valid sensor sample at rollover, the timestamp and menu counts remain pending; the first later valid sensor sample is used as an emergency environment fallback so the sales count is not discarded.
- Pending auto-save queue capacity is 8 hourly records. If the queue is full, the LCD shows AUTO FAIL / PEND FULL.
- Closed hours are skipped without probing the SD card, because no W/H sales record should be written for closed hours.
- Pending records are retried after D-key SD recovery and periodically during monitoring, with a 5-second retry interval to avoid repeated SD hammering after a persistent file-level error.
- The prediction algorithm, fallback prediction path, 1-year generation algorithm, and time-index-free storage design are unchanged.

Reset speed variance fix
- Problem found: RESET previously checked all 576 possible W/H sales filenames with SD.exists(), then deleted existing files, then called rebuildFileCache(), which again performed another 576 SD.exists() scan.
- This made RESET very slow when a 1-year generated dataset was present, but very fast when the SD card was already mostly empty.
- Storage.cpp resetSalesDataOnly() now removes only files whose fileCache bit is set.
- After each successful removal, the corresponding cache bit is cleared.
- After RESET, fileCache is cleared directly instead of rebuilding the whole cache.
- RESET also removes INITREC.BIN, INITSTAT.BIN, RESET/INIT72.BIN, and TMPREC.BIN when present.
- IceCreamSalesPredictor.ino now clears pending auto-save entries before confirmed RESET, so old unsaved hourly records cannot be written back after the sales files have been cleared.
- If deletion fails while the SD card is still accessible, the UI shows RESET WARN / FILES LEFT instead of incorrectly treating every deletion issue as SD missing.


INIT_COLLECT SD-check LCD notice
- During 72-hour measurement mode, pressing D short now immediately shows:
  SD CHECKING
  PLEASE WAIT
- This is display-only feedback before the existing SD/RESET_COLLECT check.
- No INIT72 import behavior, reset flow, prediction logic, auto-save logic, or generation algorithm was changed.
