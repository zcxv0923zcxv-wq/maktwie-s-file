#include "HardwareIO.h"
#include "HardwareConfig.h"
#include "Utils.h"

#include <LiquidCrystal.h>
#include <Keypad.h>
#include <DHT.h>
#include <avr/pgmspace.h>

#define DHTTYPE DHT11

LiquidCrystal lcdOwner(LCD_OWNER_RS, LCD_OWNER_E, LCD_OWNER_D4, LCD_OWNER_D5, LCD_OWNER_D6, LCD_OWNER_D7);
LiquidCrystal lcdKiosk(LCD_KIOSK_RS, LCD_KIOSK_E, LCD_KIOSK_D4, LCD_KIOSK_D5, LCD_KIOSK_D6, LCD_KIOSK_D7);

DHT dht(DHT_PIN, DHTTYPE);

char keypadKeys[KEYPAD_ROWS][KEYPAD_COLS] = {
    {'1', '2', '3', 'A'},
    {'4', '5', '6', 'B'},
    {'7', '8', '9', 'C'},
    {'*', '0', '#', 'D'}
};

byte keypadRowPins[KEYPAD_ROWS] = {22, 24, 26, 28};
byte keypadColPins[KEYPAD_COLS] = {30, 32, 34, 36};

Keypad ownerKeypad = Keypad(makeKeymap(keypadKeys), keypadRowPins, keypadColPins, KEYPAD_ROWS, KEYPAD_COLS);

struct DebouncedButton {
    uint8_t pin;
    uint8_t stableLevel;
    uint8_t lastReadLevel;
    uint32_t lastChangeMs;
    bool edge;
};

static DebouncedButton kioskButtons[5] = {
    {KIOSK_MENU_A_PIN, HIGH, HIGH, 0, false},
    {KIOSK_MENU_B_PIN, HIGH, HIGH, 0, false},
    {KIOSK_MENU_C_PIN, HIGH, HIGH, 0, false},
    {KIOSK_CONFIRM_PIN, HIGH, HIGH, 0, false},
    {KIOSK_RESET_PIN, HIGH, HIGH, 0, false}
};

static bool dWaitingRelease = false;
static bool dLongFired = false;
static uint32_t dPressStartMs = 0;


static uint8_t decToBcd(uint8_t v) {
    return (uint8_t)(((v / 10U) << 4) | (v % 10U));
}

static uint8_t bcdToDec(uint8_t v) {
    return (uint8_t)(((v >> 4) * 10U) + (v & 0x0F));
}

static void ds1302BeginTransfer(void) {
    digitalWrite(RTC_CLK_PIN, LOW);
    digitalWrite(RTC_CE_PIN, HIGH);
    delayMicroseconds(4);
}

static void ds1302EndTransfer(void) {
    digitalWrite(RTC_CE_PIN, LOW);
    delayMicroseconds(4);
}

static void ds1302WriteByte(uint8_t value) {
    pinMode(RTC_DAT_PIN, OUTPUT);
    for (uint8_t i = 0; i < 8; i++) {
        digitalWrite(RTC_DAT_PIN, (value & 0x01) ? HIGH : LOW);
        delayMicroseconds(1);
        digitalWrite(RTC_CLK_PIN, HIGH);
        delayMicroseconds(1);
        digitalWrite(RTC_CLK_PIN, LOW);
        delayMicroseconds(1);
        value >>= 1;
    }
}

static uint8_t ds1302ReadByte(void) {
    uint8_t value = 0;
    pinMode(RTC_DAT_PIN, INPUT);
    for (uint8_t i = 0; i < 8; i++) {
        if (digitalRead(RTC_DAT_PIN)) {
            value |= (uint8_t)(1U << i);
        }
        digitalWrite(RTC_CLK_PIN, HIGH);
        delayMicroseconds(1);
        digitalWrite(RTC_CLK_PIN, LOW);
        delayMicroseconds(1);
    }
    return value;
}

static uint8_t ds1302ReadRegister(uint8_t writeAddress) {
    uint8_t value;
    ds1302BeginTransfer();
    ds1302WriteByte(writeAddress | 0x01);
    value = ds1302ReadByte();
    ds1302EndTransfer();
    return value;
}

static void ds1302WriteRegister(uint8_t writeAddress, uint8_t value) {
    ds1302BeginTransfer();
    ds1302WriteByte(writeAddress & 0xFE);
    ds1302WriteByte(value);
    ds1302EndTransfer();
}

static void ds1302SetDateTime(uint16_t yearFull,
                              uint8_t month,
                              uint8_t day,
                              uint8_t hour,
                              uint8_t minute,
                              uint8_t second) {
    if (yearFull < 2000 || yearFull > 2099) return;
    if (month < 1 || month > 12 || day < 1 || day > 31) return;
    if (hour > 23 || minute > 59 || second > 59) return;

    uint8_t yearOffset = (uint8_t)(yearFull - 2000U);
    uint8_t dow = getDayOfWeek(yearOffset, month, day); // 0=Mon
    uint8_t dsDow = (uint8_t)(dow + 1U);                // stored as 1~7

    ds1302WriteRegister(0x8E, 0x00); // write protect off
    ds1302WriteRegister(0x80, decToBcd(second) & 0x7F); // CH=0, oscillator running
    ds1302WriteRegister(0x82, decToBcd(minute));
    ds1302WriteRegister(0x84, decToBcd(hour));          // 24-hour mode
    ds1302WriteRegister(0x86, decToBcd(day));
    ds1302WriteRegister(0x88, decToBcd(month));
    ds1302WriteRegister(0x8A, decToBcd(dsDow));
    ds1302WriteRegister(0x8C, decToBcd(yearOffset));
    ds1302WriteRegister(0x8E, 0x80); // write protect on
}


static void updateDebouncedButton(DebouncedButton* b) {
    uint8_t nowLevel = digitalRead(b->pin);
    uint32_t nowMs = millis();

    b->edge = false;

    if (nowLevel != b->lastReadLevel) {
        b->lastReadLevel = nowLevel;
        b->lastChangeMs = nowMs;
    }

    if ((nowMs - b->lastChangeMs) >= BUTTON_DEBOUNCE_MS && nowLevel != b->stableLevel) {
        uint8_t oldStable = b->stableLevel;
        b->stableLevel = nowLevel;
        if (oldStable == HIGH && b->stableLevel == LOW) {
            b->edge = true;
        }
    }
}

static bool consumeButtonEdge(uint8_t idx) {
    updateDebouncedButton(&kioskButtons[idx]);
    return kioskButtons[idx].edge;
}

void hardwareBegin(void) {
    pinMode(KIOSK_MENU_A_PIN, INPUT_PULLUP);
    pinMode(KIOSK_MENU_B_PIN, INPUT_PULLUP);
    pinMode(KIOSK_MENU_C_PIN, INPUT_PULLUP);
    pinMode(KIOSK_CONFIRM_PIN, INPUT_PULLUP);
    pinMode(KIOSK_RESET_PIN, INPUT_PULLUP);

    pinMode(LED_RED_PIN, OUTPUT);
    pinMode(LED_GREEN_PIN, OUTPUT);
    pinMode(LED_BLUE_PIN, OUTPUT);

    pinMode(CDS_PIN, INPUT);
    pinMode(FLOOR_TEMP_PIN, INPUT);
    pinMode(IR_PIN, INPUT);

    pinMode(RTC_CE_PIN, OUTPUT);
    pinMode(RTC_DAT_PIN, INPUT);
    pinMode(RTC_CLK_PIN, OUTPUT);
    digitalWrite(RTC_CE_PIN, LOW);
    digitalWrite(RTC_CLK_PIN, LOW);

#if RTC_SET_TIME_ON_UPLOAD
    ds1302SetDateTime(RTC_SET_YEAR_FULL,
                      RTC_SET_MONTH,
                      RTC_SET_DAY,
                      RTC_SET_HOUR,
                      RTC_SET_MINUTE,
                      RTC_SET_SECOND);
#endif

    ownerKeypad.setDebounceTime(30);
    ownerKeypad.setHoldTime(D_LONG_PRESS_MS);

    lcdOwner.begin(16, 2);
    lcdKiosk.begin(16, 2);
    dht.begin();

    setLedMonitoring();
    showOwnerMessage(F("SYSTEM START"), F("CHECK SD"));
    showKioskOrder(0, 0, 0);
}

bool readKioskMenuAEdge(void) { return consumeButtonEdge(0); }
bool readKioskMenuBEdge(void) { return consumeButtonEdge(1); }
bool readKioskMenuCEdge(void) { return consumeButtonEdge(2); }
bool readKioskConfirmEdge(void) { return consumeButtonEdge(3); }
bool readKioskResetEdge(void) { return consumeButtonEdge(4); }

OwnerKeyEvent readOwnerKeyEvent(void) {
    OwnerKeyEvent ev;
    ev.type = OWNER_KEY_NONE;
    ev.key = 0;

    bool dActive = false;
    uint32_t nowMs = millis();

    if (ownerKeypad.getKeys()) {
        for (byte i = 0; i < LIST_MAX; i++) {
            char k = ownerKeypad.key[i].kchar;
            KeyState st = ownerKeypad.key[i].kstate;

            if (k == NO_KEY) {
                continue;
            }

            if (k == 'D') {
                dActive = (st == PRESSED || st == HOLD);

                if (st == PRESSED) {
                    dWaitingRelease = true;
                    dLongFired = false;
                    dPressStartMs = nowMs;
                    return ev;
                }

                if ((st == HOLD || (dWaitingRelease && dActive)) && !dLongFired) {
                    if ((nowMs - dPressStartMs) >= D_LONG_PRESS_MS) {
                        dLongFired = true;
                        ev.type = OWNER_KEY_D_LONG;
                        ev.key = 'D';
                        return ev;
                    }
                }

                if (st == RELEASED) {
                    if (dWaitingRelease && !dLongFired) {
                        ev.type = OWNER_KEY_D_SHORT;
                        ev.key = 'D';
                    }
                    dWaitingRelease = false;
                    dLongFired = false;
                    dPressStartMs = 0;
                    return ev;
                }
            } else if (st == PRESSED) {
                ev.type = OWNER_KEY_NORMAL;
                ev.key = k;
                return ev;
            }
        }
    }

    if (dWaitingRelease && !dLongFired && dPressStartMs != 0) {
        if ((nowMs - dPressStartMs) >= D_LONG_PRESS_MS) {
            dLongFired = true;
            ev.type = OWNER_KEY_D_LONG;
            ev.key = 'D';
            return ev;
        }
    }

    return ev;
}

static void addSecondsToDateTime(DateTimeParts* dt, uint32_t sec) {
    while (sec >= 3600UL) {
        dt->hour++;
        if (dt->hour >= 24) {
            dt->hour = 0;
            dt->day++;
            if (dt->day > daysInMonth(dt->yearOffset, dt->month)) {
                dt->day = 1;
                dt->month++;
                if (dt->month > 12) {
                    dt->month = 1;
                    dt->yearOffset++;
                }
            }
            dt->dayOfWeek = (dt->dayOfWeek + 1) % 7;
        }
        sec -= 3600UL;
    }

    uint16_t totalMin = dt->minute + (sec / 60UL);
    dt->minute = totalMin % 60;
    dt->hour += totalMin / 60;
    if (dt->hour >= 24) {
        uint8_t extraDays = dt->hour / 24;
        dt->hour %= 24;
        while (extraDays--) {
            dt->day++;
            if (dt->day > daysInMonth(dt->yearOffset, dt->month)) {
                dt->day = 1;
                dt->month++;
                if (dt->month > 12) {
                    dt->month = 1;
                    dt->yearOffset++;
                }
            }
            dt->dayOfWeek = (dt->dayOfWeek + 1) % 7;
        }
    }
    dt->second = sec % 60;
}

bool readRtcDateTime(DateTimeParts* out) {
    if (out == NULL) return false;

    uint8_t rawSec = ds1302ReadRegister(0x80);
    uint8_t rawMin = ds1302ReadRegister(0x82);
    uint8_t rawHour = ds1302ReadRegister(0x84);
    uint8_t rawDay = ds1302ReadRegister(0x86);
    uint8_t rawMonth = ds1302ReadRegister(0x88);
    uint8_t rawYear = ds1302ReadRegister(0x8C);

    if (rawSec & 0x80) {
        return false; // oscillator stopped or RTC time has not been started
    }

    uint8_t second = bcdToDec(rawSec & 0x7F);
    uint8_t minute = bcdToDec(rawMin & 0x7F);
    uint8_t hour;

    if (rawHour & 0x80) {
        uint8_t h12 = bcdToDec(rawHour & 0x1F);
        bool pm = (rawHour & 0x20) != 0;
        if (h12 == 12) hour = pm ? 12 : 0;
        else hour = pm ? (uint8_t)(h12 + 12U) : h12;
    } else {
        hour = bcdToDec(rawHour & 0x3F);
    }

    uint8_t day = bcdToDec(rawDay & 0x3F);
    uint8_t month = bcdToDec(rawMonth & 0x1F);
    uint8_t yearOffset = bcdToDec(rawYear);

    if (second > 59 || minute > 59 || hour > 23) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > daysInMonth(yearOffset, month)) return false;

    out->yearOffset = yearOffset;
    out->month = month;
    out->day = day;
    out->hour = hour;
    out->minute = minute;
    out->second = second;
    out->dayOfWeek = getDayOfWeek(yearOffset, month, day);

    return true;
}

bool readSensors(SensorSnapshot* out) {
    if (out == NULL) return false;

    int cdsRaw = analogRead(CDS_PIN);
    int floorRaw = analogRead(FLOOR_TEMP_PIN);
    int irRaw = analogRead(IR_PIN);

    float dhtTemp = dht.readTemperature();
    float dhtHum = dht.readHumidity();

    bool dhtOk = !(isnan(dhtTemp) || isnan(dhtHum));

    if (dhtOk) {
        int16_t temp10 = (int16_t)(dhtTemp * 10.0f);
        uint16_t hum2v = (uint16_t)(dhtHum * 2.0f);
        if (hum2v > 255U) hum2v = 255U;
        out->airTemp10 = temp10;
        out->humidity2 = (uint8_t)hum2v;
    } else {
        out->airTemp10 = 250;
        out->humidity2 = 100;
    }

    if (cdsRaw < 0) cdsRaw = 0;
    if (cdsRaw > 1023) cdsRaw = 1023;
    if (irRaw < 0) irRaw = 0;
    if (irRaw > 1023) irRaw = 1023;

    out->cdsValue = (uint16_t)(1023 - cdsRaw);
    out->irValue = (uint16_t)irRaw;

    if (floorRaw < 0) floorRaw = 0;
    if (floorRaw > 1023) floorRaw = 1023;

    if (FLOOR_TEMP_SOURCE == FLOOR_TEMP_SOURCE_LM35) {
        out->floorTemp10 = (int16_t)(900L - (int32_t)floorRaw * 5000L / 1023L);
    } else {
        out->floorTemp10 = out->airTemp10;
    }

    out->valid = true;
    return true;
}

void setLedMonitoring(void) {
    digitalWrite(LED_RED_PIN, LOW);
    digitalWrite(LED_GREEN_PIN, HIGH);
    digitalWrite(LED_BLUE_PIN, LOW);
}

void setLedInput(void) {
    digitalWrite(LED_RED_PIN, LOW);
    digitalWrite(LED_GREEN_PIN, LOW);
    digitalWrite(LED_BLUE_PIN, HIGH);
}

void setLedError(void) {
    digitalWrite(LED_RED_PIN, HIGH);
    digitalWrite(LED_GREEN_PIN, LOW);
    digitalWrite(LED_BLUE_PIN, LOW);
}

void setLedOff(void) {
    digitalWrite(LED_RED_PIN, LOW);
    digitalWrite(LED_GREEN_PIN, LOW);
    digitalWrite(LED_BLUE_PIN, LOW);
}

void blinkGreenOnce(void) {
    digitalWrite(LED_GREEN_PIN, HIGH);
}

void blinkBlueOnce(void) {
    digitalWrite(LED_BLUE_PIN, HIGH);
}

void blinkRedOnce(void) {
    digitalWrite(LED_RED_PIN, HIGH);
}

static void lcdPrintPadded(LiquidCrystal* lcd, const char* text) {
    uint8_t i = 0;
    while (text != NULL && text[i] != '\0' && i < 16) {
        lcd->print(text[i]);
        i++;
    }
    while (i < 16) {
        lcd->print(' ');
        i++;
    }
}

static void lcdPrintFlashPadded(LiquidCrystal* lcd, const __FlashStringHelper* text) {
    uint8_t i = 0;
    const char* p = (const char*)text;
    while (i < 16) {
        char ch = (char)pgm_read_byte(p + i);
        if (ch == '\0') break;
        lcd->print(ch);
        i++;
    }
    while (i < 16) {
        lcd->print(' ');
        i++;
    }
}

void showOwnerMessage(const __FlashStringHelper* line1, const __FlashStringHelper* line2) {
    lcdOwner.setCursor(0, 0);
    lcdPrintFlashPadded(&lcdOwner, line1);
    lcdOwner.setCursor(0, 1);
    lcdPrintFlashPadded(&lcdOwner, line2);
}

void showOwnerText(const char* line1, const char* line2) {
    lcdOwner.setCursor(0, 0);
    lcdPrintPadded(&lcdOwner, line1);
    lcdOwner.setCursor(0, 1);
    lcdPrintPadded(&lcdOwner, line2);
}

void showOwnerSales(uint8_t hour, uint8_t minute, uint8_t a, uint8_t b, uint8_t c) {
    char l1[17];
    char l2[17];
    if (hour > 23) hour = 23;
    if (minute > 59) minute = 59;
    if (a > 99) a = 99;
    if (b > 99) b = 99;
    if (c > 99) c = 99;
    snprintf_P(l1, sizeof(l1), PSTR("AUTO %02u:%02u"), (unsigned)hour, (unsigned)minute);
    snprintf_P(l2, sizeof(l2), PSTR("A:%02u B:%02u C:%02u"), (unsigned)a, (unsigned)b, (unsigned)c);
    showOwnerText(l1, l2);
}

void showOwnerPrediction(uint16_t a, uint16_t b, uint16_t c, uint8_t conf, uint8_t used) {
    char l1[17];
    char l2[17];
    uint8_t confNum = conf;
    if (confNum > CONF_HIGH) confNum = CONF_NONE;
    if (used > 99) used = 99;
    if (a > 999U) a = 999U;
    if (b > 999U) b = 999U;
    if (c > 999U) c = 999U;
    snprintf_P(l1, sizeof(l1), PSTR("CONF %u U%02u"), (unsigned)confNum, (unsigned)used);
    snprintf_P(l2, sizeof(l2), PSTR("A%03u B%03u C%03u"), (unsigned)a, (unsigned)b, (unsigned)c);
    showOwnerText(l1, l2);
}

void showKioskOrder(uint8_t a, uint8_t b, uint8_t c) {
    char l2[17];
    if (a > 99) a = 99;
    if (b > 99) b = 99;
    if (c > 99) c = 99;
    lcdKiosk.setCursor(0, 0);
    lcdPrintFlashPadded(&lcdKiosk, F("ORDER"));
    snprintf_P(l2, sizeof(l2), PSTR("A:%02u B:%02u C:%02u"), (unsigned)a, (unsigned)b, (unsigned)c);
    lcdKiosk.setCursor(0, 1);
    lcdPrintPadded(&lcdKiosk, l2);
}

void showKioskSaved(void) {
    lcdKiosk.setCursor(0, 0);
    lcdPrintFlashPadded(&lcdKiosk, F("ORDER SAVED"));
    lcdKiosk.setCursor(0, 1);
    lcdPrintFlashPadded(&lcdKiosk, F("THANK YOU"));
}

void showKioskReset(void) {
    lcdKiosk.setCursor(0, 0);
    lcdPrintFlashPadded(&lcdKiosk, F("ORDER RESET"));
    lcdKiosk.setCursor(0, 1);
    lcdPrintFlashPadded(&lcdKiosk, F("SELECT MENU"));
}

void showInitCollect(uint8_t dayNum) {
    char l1[17];
    snprintf_P(l1, sizeof(l1), PSTR("INIT COL D%u/3"), (unsigned)dayNum);
    lcdOwner.setCursor(0, 0);
    lcdPrintPadded(&lcdOwner, l1);
    lcdOwner.setCursor(0, 1);
    lcdPrintFlashPadded(&lcdOwner, F("cancel hold D"));
}

void showInitCollectStatus(uint16_t done, uint16_t total, uint8_t hour, uint8_t minute, uint8_t a, uint8_t b, uint8_t c) {
    char l1[17];
    char l2[17];

    if (total > 99U) total = 99U;
    if (done > total) done = total;
    if (hour > 23) hour = 23;
    if (minute > 59) minute = 59;

    snprintf_P(l1, sizeof(l1), PSTR("INIT %02u/%02u %02u:%02u"), (unsigned)done, (unsigned)total, (unsigned)hour, (unsigned)minute);
    snprintf_P(l2, sizeof(l2), PSTR("A%03u B%03u C%03u"), (unsigned)a, (unsigned)b, (unsigned)c);
    showOwnerText(l1, l2);
}

void showInitMake(uint16_t done, uint16_t total) {
    char l2[17];
    snprintf_P(l2, sizeof(l2), PSTR("%04u/%04u"), (unsigned)done, (unsigned)total);
    lcdOwner.setCursor(0, 0);
    lcdPrintFlashPadded(&lcdOwner, F("INIT MAKE"));
    lcdOwner.setCursor(0, 1);
    lcdPrintPadded(&lcdOwner, l2);
}

void showInitDone(void) {
    showOwnerMessage(F("INIT DONE"), F("START SYSTEM"));
}

void showResetConfirm(void) {
    showOwnerMessage(F("RESET?"), F("YES(A) / NO(B)"));
}
