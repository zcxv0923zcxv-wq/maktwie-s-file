#ifndef UTILS_H
#define UTILS_H

#include <Arduino.h>
#include "Types.h"

uint8_t getTempZone(int16_t airTemp10);
uint8_t getLightZone(uint16_t cdsValue);
bool isOpenHour(uint8_t hour);
bool isHolidayDate(uint8_t yearOffset, uint8_t month, uint8_t day);
uint8_t getDayOfWeek(uint8_t yearOffset, uint8_t month, uint8_t day);
uint16_t dayOfYear(uint8_t yearOffset, uint8_t month, uint8_t day);
bool addDaysToDate(uint8_t yearOffset, uint8_t month, uint8_t day, uint16_t addDays,
                   uint8_t* outYearOffset, uint8_t* outMonth, uint8_t* outDay);
uint8_t daysInMonth(uint8_t yearOffset, uint8_t month);
bool isLeapYearOffset(uint8_t yearOffset);
uint32_t makeTimestampKey(uint8_t y, uint8_t m, uint8_t d, uint8_t h);
bool isFutureRecord(const PredictionContext* ctx, const SalesRecord* r);
uint8_t xorChecksumBytes(const uint8_t* data, uint8_t len);

#endif
