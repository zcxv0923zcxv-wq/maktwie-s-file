#!/usr/bin/env python3
"""
Decode Arduino SalesRecord binary files (WxxTnLm.BIN / HxxTnLm.BIN) to CSV.
Usage:
  python decode_sales_records.py [sd_root] [output_csv]
Example:
  python decode_sales_records.py E:\\ sales_decoded.csv
"""
from __future__ import annotations
import csv
import struct
import sys
from pathlib import Path

RECORD = struct.Struct('<BBBBhBhHHBBB')
# yearOffset, month, day, hour, airTemp10, humidity2, floorTemp10, cdsValue, irValue, menuA, menuB, menuC

def decode_file(path: Path):
    raw = path.read_bytes()
    usable = len(raw) - (len(raw) % RECORD.size)
    for pos in range(0, usable, RECORD.size):
        y, m, d, h, air10, hum2, floor10, cds, ir, a, b, c = RECORD.unpack_from(raw, pos)
        yield {
            'file': path.name,
            'record_index': pos // RECORD.size,
            'year': 2000 + y,
            'month': m,
            'day': d,
            'hour': h,
            'air_temp_c': air10 / 10.0,
            'humidity_pct': hum2 / 2.0,
            'floor_temp_c': floor10 / 10.0,
            'cds': cds,
            'ir': ir,
            'menuA': a,
            'menuB': b,
            'menuC': c,
        }

def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) >= 2 else Path('.')
    out = Path(sys.argv[2]) if len(sys.argv) >= 3 else Path('sales_decoded.csv')
    files = sorted([*root.glob('W??T?L?.BIN'), *root.glob('H??T?L?.BIN')])
    rows = []
    for f in files:
        rows.extend(decode_file(f))
    rows.sort(key=lambda r: (r['year'], r['month'], r['day'], r['hour'], r['file'], r['record_index']))
    fieldnames = ['file','record_index','year','month','day','hour','air_temp_c','humidity_pct','floor_temp_c','cds','ir','menuA','menuB','menuC']
    with out.open('w', newline='', encoding='utf-8-sig') as fp:
        w = csv.DictWriter(fp, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    print(f'Decoded {len(rows)} records from {len(files)} files -> {out}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
