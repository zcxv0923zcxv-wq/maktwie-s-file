RESET/INIT72.BIN demo data for Arduino test

'
'Place the RESET folder at the SD card root.
'
'Expected SD layout:
'
'  /WEIGHT.BIN
'
'  /RESET/INIT72.BIN

'
'INIT72.BIN contains exactly 72 consecutive 16-byte SalesRecord entries.
'
'Start: 2026-06-13 00:00
'
'End:   2026-06-15 23:00
'
'Generation basis: WEIGHT.BIN hourly environment fields and totalOffset were used.
'
'Closed hours have menuA/B/C = 0. Open hours use an ice-cream-shop-like weighted hourly sales profile.
'
'INIT72_preview.csv is for laptop checking only; Arduino reads INIT72.BIN.
